import json
import os

from dotenv import load_dotenv
from langchain.embeddings import OpenAIEmbeddings
from langchain.schema import Document
from langchain.vectorstores.azuresearch import AzureSearch

load_dotenv()

with open(os.path.abspath('temp_data/documents.json'), 'r') as json_file:
    list_of_parsed_documents = json.load(json_file)

# Criando os documentos
documents_to_index = []

for doc in list_of_parsed_documents:
    for chunk in doc['chunks_of_contents']:
        documents_to_index.append(Document(
            page_content=chunk['final_chunk'],
            metadata={
                'source': doc['document_name'],
            }))

# Embeddings Service
embeddings = OpenAIEmbeddings(deployment=os.getenv("EMBEDDING_DEPLOYMENT_NAME"), chunk_size=1)

# Inserindo na vector store
vector_store = AzureSearch(
    azure_search_endpoint=os.getenv("AZURE_SEARCH_ENDPOINT"),
    azure_search_key=os.getenv("AZURE_SEARCH_ADMIN_KEY"),
    index_name=os.getenv("AZURE_SEARCH_INDEX_NAME"),
    embedding_function=embeddings.embed_query
)

vector_store.add_documents(documents_to_index)
