from gpt_api import GPTTjsp
from dotenv import load_dotenv

import uuid

load_dotenv()

perguntas = [
    # 'como importar guia de recolhimento do BNMP para o SAJ?',
    # 'como faço para alterar a situação do réu no BNMP, após a expedição do alvará de soltura ou ordem de liberação?',
    # 'o que quer dizer Mandado Auto cumprido?',
    # 'o que fazer quando existem diversos cadastros de pessoas diferentes com o mesmo RJI?',
    # 'Estou com processo que está com mandado pendente. Neste caso como faço para emitir a Certidão de extinção de punibilidade por morte? ',
    # 'Eu consigo pesquisar os dados de alguém apenas com o nome completo ou preciso ter o RJI, para emitir a certidão de extinção de punibilidade de morte? ',
    # 'Qual o link do BNMP? E se o sistema estiver indisponível? ',
    # 'Eu não tenho o cadastro no sistema BNMP, como faço para conseguir? E qual o tipo de acesso/consulta que eu posso ter?  ',
    # 'Esqueci o número da lei para selecionar a tipificação penal. Como eu faço agora? ',
    # 'Quais são os tipos de penas impostas disponíveis?',
    # 'como faço para alterar a situação do réu no BNMP, após a confirmação da prisão com a guia de execução da pena?',
    'Como faço para inserir penas de multa?',
    # 'Quem foi michael jackson?',
]
gpt = GPTTjsp()


# for pergunta in perguntas:
#     session_id = str(uuid.uuid4())
#     resposta = gpt.execute(session=session_id, message=pergunta)[0]
#     # resposta, chat_history = gpt.execute(session="1", message=pergunta)
#     print("Pergunta:", pergunta)
#     print("Resposta:", resposta)
#     # print("chat_history:", chat_history)




for _ in range(1,10):
    session_id = str(uuid.uuid4())
    for pergunta in perguntas:
        resposta, chat_history = gpt.execute(session_id, message=pergunta)
        print("Pergunta:", pergunta)
        print("Resposta:", resposta)
        print("chat_history:", chat_history)