from .gpt_tjsp import GPTTjsp
from .gpt_tjsp_descricao import GPTTjspDescricao
from .gpt_tjsp_classificador import GPTTjspClassificador
