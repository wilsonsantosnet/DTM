import os
import tiktoken

from langchain import LLMChain
from langchain.prompts import load_prompt
from langchain.vectorstores.azuresearch import AzureSearch

from azure.cosmos import CosmosClient, PartitionKey
from azure.cosmos.exceptions import CosmosResourceNotFoundError

from langchain.embeddings import OpenAIEmbeddings
from langchain.chat_models import AzureChatOpenAI
import openai


class GPTTjsp:

    def __init__(self):

        openai.api_type = "azure"
        openai.api_base = os.getenv("BASE_URL")
        openai.api_version = os.getenv("API_VERSION")
        openai.api_key = os.getenv("API_KEY")

        self.llm_chat = AzureChatOpenAI(
            deployment_name=os.getenv("DEPLOYMENT_NAME"),
            openai_api_type="azure",
            temperature=0.0,
            request_timeout=30
        )

        self.embeddings = OpenAIEmbeddings(
            model="text-embedding-ada-002",
            deployment=os.getenv("EMBEDDING_DEPLOYMENT_NAME"),
            openai_api_type="azure",
            chunk_size=1
        )

        self.vectorstore = AzureSearch(
            azure_search_endpoint=os.getenv("AZURE_SEARCH_ENDPOINT"),
            azure_search_key=os.getenv("AZURE_SEARCH_ADMIN_KEY"),
            index_name=os.getenv("AZURE_SEARCH_INDEX_NAME"),
            embedding_function=self.embeddings.embed_query
        )

        self.prompt_qa = load_prompt(f"{os.getcwd()}/prompts/qa_v2.json")

        self.cosmos_client = CosmosClient(
            url=os.environ['COSMOS_URL'],
            credential=os.environ['COSMOS_KEY']
        )

    def get_cosmos_container_client(self):

        cosmos_database_name = os.getenv("COSMOS_DATABASE_NAME")
        cosmos_container_name = os.getenv("COSMOS_CONTAINER_NAME")

        self.cosmos_client.create_database_if_not_exists(cosmos_database_name)

        database = self.cosmos_client.get_database_client(cosmos_database_name)

        database.create_container_if_not_exists(id=cosmos_container_name, partition_key=PartitionKey(path="/id"))

        container = database.get_container_client(cosmos_container_name)

        return container

    @staticmethod
    def get_chat_history(container, session):

        try:
            item = container.read_item(session, partition_key=session)
        except CosmosResourceNotFoundError:
            item = {'id': session, 'chat_history': []}

        return item

    @staticmethod
    def _format_chat_history(item_chat_history, k: int = None):
        messages_formated = []
        chat_history_only_questions = []

        if k is None:
            chat_history = item_chat_history['chat_history']
        else:
            chat_history = item_chat_history['chat_history'][-k:]

        for message in chat_history:
            messages_formated.append(f'HUMAN_INPUT: {message["HUMAN_INPUT"]}')
            messages_formated.append(f'AI: {message["AI"]}')
            chat_history_only_questions.append(message['HUMAN_INPUT'])

        return '\n'.join(messages_formated), ' '.join(chat_history_only_questions)

    def execute(self, session, message):

        # Recupera histórico de conversa formatado
        container = self.get_cosmos_container_client()

        item_chat_history = self.get_chat_history(container, session)

        prompt_chat_history, chat_history_questions = self._format_chat_history(item_chat_history, k=5)

        # Chain conversacional
        llm_chain = LLMChain(prompt=self.prompt_qa, llm=self.llm_chat, verbose=False)

        # Recuperar o contexto em vector store
        contexto_scores = self.vectorstore.vector_search_with_score(query=message, k=5)

        if chat_history_questions != '':
            chat_history_context = self.vectorstore.vector_search_with_score(query=chat_history_questions, k=5)
            contexto_scores.extend(chat_history_context)

        contexto = [doc for doc, _ in contexto_scores]

        cl100k_base = tiktoken.get_encoding("cl100k_base")
        list_context = {documento.page_content for documento in contexto}

        len_chat_history = len(cl100k_base.encode(prompt_chat_history))
        len_message = len(cl100k_base.encode(message))

        while True:

            len_contexto = len(cl100k_base.encode('\n'.join(list_context)))
            len_total = len_contexto + len_chat_history + len_message

            if len_total > 7600:
                list_context.pop()
            else:
                break

        final_context = '\n'.join(list_context).replace("( )", "")

        response = llm_chain.run(human_input=message, chat_history=prompt_chat_history, context=final_context)

        item_chat_history['chat_history'].append({"HUMAN_INPUT": message, "AI": response})

        # salva histórico da conversa
        container.upsert_item(item_chat_history)

        return response, prompt_chat_history
