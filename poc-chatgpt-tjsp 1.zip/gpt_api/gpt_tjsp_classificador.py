import json
import os

import openai
import tiktoken
from azure.cosmos import CosmosClient, PartitionKey
from langchain import LLMChain
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.prompts import load_prompt


class GPTTjspClassificador:

    def __init__(self):

        openai.api_type = "azure"
        openai.api_base = os.getenv("BASE_URL")
        openai.api_version = os.getenv("API_VERSION")
        openai.api_key = os.getenv("API_KEY")

        self.llm_chat = AzureChatOpenAI(
            deployment_name=os.getenv("DEPLOYMENT_NAME"),
            openai_api_type="azure",
            temperature=0.0,
            request_timeout=20
        )

        self.embeddings = OpenAIEmbeddings(
            model="text-embedding-ada-002",
            deployment=os.getenv("EMBEDDING_DEPLOYMENT_NAME"),
            openai_api_type="azure",
            chunk_size=1
        )

        self.prompt_classificador = load_prompt(f"{os.getcwd()}/prompts/classificador.json")

        self.prompt_parse_classificador = load_prompt(f"{os.getcwd()}/prompts/parse_classificador.json")

        self.cosmos_client = CosmosClient(
            url=os.environ['COSMOS_URL'],
            credential=os.environ['COSMOS_KEY']
        )

    def get_cosmos_container_client(self):

        cosmos_database_name = os.getenv("COSMOS_DATABASE_NAME")
        cosmos_container_name = os.getenv("COSMOS_CONTAINER_NAME")

        self.cosmos_client.create_database_if_not_exists(cosmos_database_name)

        database = self.cosmos_client.get_database_client(cosmos_database_name)

        database.create_container_if_not_exists(id=cosmos_container_name, partition_key=PartitionKey(path="/id"))

        container = database.get_container_client(cosmos_container_name)

        return container

    def execute(self, descricao, ofertas):

        lista_categoria_rotulo = []

        for entity in ofertas['entities']:
            # Aqui, você pode acessar os campos de cada objeto individualmente
            catalog_category = entity['properties']['CatalogCategory_c']
            entity_id = entity['properties']['Id']
            display_label = entity['properties']['DisplayLabel']
            lista_categoria_rotulo.append(f"{{'Id': '{entity_id}', 'descricao': '{catalog_category}-{display_label}'}}")

        cl100k_base = tiktoken.get_encoding("cl100k_base")

        while True:

            categoria_rotulo = '\n'.join(lista_categoria_rotulo)

            prompt_final = self.prompt_classificador.format(descricao=descricao, lista_categorias=categoria_rotulo)
            len_prompt_final = len(cl100k_base.encode(prompt_final))
            print("len_prompt_final:", len_prompt_final)

            # Paliativo para cada o catalogo cresca. Sugestao de melhoria: usar modelo com mais tokens ou realizar encadeamento de prompts.
            # Motivo do paliativo: Tempo para implementação do piloto. Optou-se por uma solução mais simples.
            if len_prompt_final > 8000:
                lista_categoria_rotulo.pop(0)

            else:
                break

        # Chain Classificador
        llm_chain_classificador = LLMChain(prompt=self.prompt_classificador, llm=self.llm_chat, verbose=True)
        response_top3_categorias = llm_chain_classificador.run(descricao=descricao, lista_categorias=categoria_rotulo)

        # Chain Retorna Json
        llm_chain_parse_classificador = LLMChain(prompt=self.prompt_parse_classificador, llm=self.llm_chat, verbose=True)
        chain_response_classificador = llm_chain_parse_classificador.run(categorias=response_top3_categorias)

        json_categorias = json.loads(chain_response_classificador)

        lista_categorias = json_categorias['categorias']

        tres_categorias = []

        for entity in ofertas['entities']:
            if entity['properties']['Id'] in lista_categorias:
                tres_categorias.append(
                    {
                        'id_categoria': entity['properties']['Id'],
                        'display_label': entity['properties']['DisplayLabel'],
                        'catalog_category': entity['properties']['CatalogCategory_c']
                    }
                )

        response = {
            'id_categoria_1': tres_categorias[0]['id_categoria'],
            'label_1': tres_categorias[0]['display_label'],
            'catalogo_categoria_1': tres_categorias[0]['catalog_category'],

            'id_categoria_2': tres_categorias[1]['id_categoria'],
            'label_2': tres_categorias[1]['display_label'],
            'catalogo_categoria_2': tres_categorias[1]['catalog_category'],

            'id_categoria_3': tres_categorias[2]['id_categoria'],
            'label_3': tres_categorias[2]['display_label'],
            'catalogo_categoria_3': tres_categorias[2]['catalog_category']
        }

        return response
