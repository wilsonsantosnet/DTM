import os

import openai
from azure.cosmos import CosmosClient, PartitionKey
from langchain import LLMChain
from langchain.chat_models import AzureChatOpenAI
from langchain.prompts import load_prompt


class GPTTjspDescricao:

    def __init__(self):

        openai.api_type = "azure"
        openai.api_base = os.getenv("BASE_URL")
        openai.api_version = os.getenv("API_VERSION")
        openai.api_key = os.getenv("API_KEY")

        self.llm_chat = AzureChatOpenAI(
            deployment_name=os.getenv("DEPLOYMENT_NAME"),
            openai_api_type="azure",
            temperature=0.0,
            request_timeout=20
        )

        self.prompt_qa = load_prompt(f"{os.getcwd()}/prompts/descricao.json")

        self.cosmos_client = CosmosClient(
            url=os.environ['COSMOS_URL'],
            credential=os.environ['COSMOS_KEY']
        )

    def get_cosmos_container_client(self):

        cosmos_database_name = os.getenv("COSMOS_DATABASE_NAME")
        cosmos_container_name = os.getenv("COSMOS_CONTAINER_NAME")

        self.cosmos_client.create_database_if_not_exists(cosmos_database_name)

        database = self.cosmos_client.get_database_client(cosmos_database_name)

        database.create_container_if_not_exists(id=cosmos_container_name, partition_key=PartitionKey(path="/id"))

        container = database.get_container_client(cosmos_container_name)

        return container

    def execute(self, chat_history):

        # Chain conversacional
        llm_chain = LLMChain(prompt=self.prompt_qa, llm=self.llm_chat, verbose=False)

        response = llm_chain.run(chat_history=chat_history)

        return response
