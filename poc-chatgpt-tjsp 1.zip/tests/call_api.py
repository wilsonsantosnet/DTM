import requests
import time

for i in range(60, 61):
    print("interação", i)
    inicio = time.time()
    body = {
        "message": "Saneamento?",
        "user": "rafaelxx1",
        "session": str(i),
        "model": "gpt-tjsp"
    }

    headers = {"API_KEY": "TJ!)#!@M#POPS"}

    response = requests.post(
        url="http://127.0.0.1:8000",
        # url="https://cont-chatgpt-tjsp.purpleriver-6e4b402a.eastus2.azurecontainerapps.io",
        # url="https://cont-itsm-chatgpt-dev.jollydesert-65bdaf5e.eastus2.azurecontainerapps.io",
        json=body,
        headers=headers
    )

    final = time.time()

    print(final - inicio)

    print(response.text)