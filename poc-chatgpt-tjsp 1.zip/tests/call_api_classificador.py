import requests

body = {
    "descricao": 'Bruno da Silva: Como faço para inserir penas de multa? '
                    '\n ChatGPT: Para inserir penas de multa, você deve clicar '
                    'no botão com o símbolo de adição na tela de Cadastro das Penas de Multa.'
                    ' Em seguida, preencha os campos "Dias-multa" e "Valor do dia-multa em SM" '
                    'e clique em "Salvar". O sistema apresentará a seção "Pena de Multa" preenchida. '
                    'Lembre-se de preencher também o campo "Regime Prisional" com uma das opções apresentadas '
                    'pelo sistema. O documento utilizado foi "BNMP - Saneamento - Preso Provisório -'
                    ' Emissão da Guia no CNJ - PARTE II - 16.02.2023.pdf", no tópico "Penas de Multa",'
                    ' subtópico "None".',
    "ofertas": {
        "entities": [
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "Use esta solicitação para mudar o local do Notebook",
                "LastUpdateTime": 1690401482669,
                "Id": "249114",
                "DisplayLabel": "NOTEBOOK - Solicitar a Mudança do Local da Máquina"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "NOTEBOOK"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Scanner",
                "LastUpdateTime": 1690401503475,
                "Id": "249123",
                "DisplayLabel": "SCANNER - Estou com problema com o Scanner"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SCANNER"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Scanner",
                "LastUpdateTime": 1690401503721,
                "Id": "249124",
                "DisplayLabel": "SCANNER - Solicitar a configuração de Scanner"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SCANNER"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Rede&nbsp;(AD - ACTIVE DIRECTORY)</p>",
                "LastUpdateTime": 1690401427474,
                "Id": "249137",
                "DisplayLabel": "ACESSO A REDE (AD) - Criação de Ad (Usuário) - Terceiro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Rede&nbsp;(AD - ACTIVE DIRECTORY)</p>",
                "LastUpdateTime": 1690401427479,
                "Id": "249138",
                "DisplayLabel": "ACESSO A REDE (AD) - Criação de Ad (Usuário) - Servidor TJSP"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Rede&nbsp;(AD - ACTIVE DIRECTORY)</p>",
                "LastUpdateTime": 1690401427981,
                "Id": "249140",
                "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY) - Desativação Ad - Terceiro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Rede&nbsp;(AD - ACTIVE DIRECTORY)</p>",
                "LastUpdateTime": 1690401428039,
                "Id": "249141",
                "DisplayLabel": "ACESSO A REDE (AD) - Reset de Ad (Usuário) - Magistrado"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Rede&nbsp;(AD - ACTIVE DIRECTORY)</p>",
                "LastUpdateTime": 1690401427813,
                "Id": "249142",
                "DisplayLabel": "ACESSO A REDE (AD) - Reset de Ad (Usuário) - Terceiro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Rede&nbsp;(AD - ACTIVE DIRECTORY)</p>",
                "LastUpdateTime": 1690401427815,
                "Id": "249145",
                "DisplayLabel": "ACESSO A REDE (AD) - Reset de Ad (Usuário) - Servidor TJSP"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Rede (AD - ACTIVE DIRECTORY)</p>",
                "LastUpdateTime": 1690401428023,
                "Id": "249146",
                "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY) - Alteração de Nome"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO A REDE (AD - ACTIVE DIRECTORY)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Certificados Digitais",
                "LastUpdateTime": 1690401428202,
                "Id": "249158",
                "DisplayLabel": "CERTIFICADOS DIGITAIS - A Leitora não Funciona"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CERTIFICADOS DIGITAIS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Certificados Digitais",
                "LastUpdateTime": 1690401427812,
                "Id": "249159",
                "DisplayLabel": "CERTIFICADOS DIGITAIS - Solicitar a Renovação"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CERTIFICADOS DIGITAIS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Certificados Digitais",
                "LastUpdateTime": 1690401427765,
                "Id": "249160",
                "DisplayLabel": "CERTIFICADOS DIGITAIS - Solicitar a Instalação"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CERTIFICADOS DIGITAIS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": " Use esta solicitação para relatar falhas ou abrir uma requisição de Certificados Digitais",
                "LastUpdateTime": 1690401428203,
                "Id": "249161",
                "DisplayLabel": "CERTIFICADOS DIGITAIS - Solicitar a Emissão de Novo Certificado"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CERTIFICADOS DIGITAIS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Certificados Digitais",
                "LastUpdateTime": 1690401427357,
                "Id": "249162",
                "DisplayLabel": "CERTIFICADOS DIGITAIS - Esqueci Minha Senha"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CERTIFICADOS DIGITAIS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (AJG - Assistência Judiciária Gratuita)</p>",
                "LastUpdateTime": 1690401428087,
                "Id": "249190",
                "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA - Cadastramento - Usuário (Quando não é Escrivão)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482512,
                "Id": "249191",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Cadastro de Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (AJG - Assistência Judiciária Gratuita)</p>",
                "LastUpdateTime": 1690401427217,
                "Id": "249192",
                "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA - Cadastramento - Magistrado (Juiz)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401481917,
                "Id": "249195",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (AJG - Assistência Judiciária Gratuita)</p>",
                "LastUpdateTime": 1690401427222,
                "Id": "249198",
                "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA - Dúvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (AJG - Assistência Judiciária Gratuita)</p>",
                "LastUpdateTime": 1690401427929,
                "Id": "249200",
                "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA - Remoção"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482300,
                "Id": "249202",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Dúvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (AJG - Assistência Judiciária Gratuita)</p>",
                "LastUpdateTime": 1690401427467,
                "Id": "249203",
                "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA - Cancelamento"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482133,
                "Id": "249204",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Cancelamento de Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482048,
                "Id": "249205",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Alteração de Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Use esta solicitação para Solicitar a Mudança de Local do Desktop</p>",
                "LastUpdateTime": 1690401363438,
                "Id": "249323",
                "DisplayLabel": "DESKTOP - Solicitar Mudança de Local do Desktop"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DESKTOP"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Internet",
                "LastUpdateTime": 1690401427967,
                "Id": "249357",
                "DisplayLabel": "ACESSO À INTERNET - Acesso ao Site Bloqueado"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO À INTERNET"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Internet",
                "LastUpdateTime": 1690401426467,
                "Id": "249358",
                "DisplayLabel": "ACESSO À INTERNET - A Internet está Lenta"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO À INTERNET"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Acesso à Internet",
                "LastUpdateTime": 1690401427992,
                "Id": "249359",
                "DisplayLabel": "ACESSO À INTERNET - Não Consigo Acessar a Internet"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACESSO À INTERNET"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Backup</p>",
                "LastUpdateTime": 1690401428005,
                "Id": "249373",
                "DisplayLabel": "BACKUP - Duvidas e Orientações"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "BACKUP"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "MENSAGERIA / COLABORAÇÃO",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Teams",
                "LastUpdateTime": 1690401503385,
                "Id": "298364",
                "DisplayLabel": "TEAMS - Dúvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "TEAMS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "MENSAGERIA / COLABORAÇÃO",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Teams",
                "LastUpdateTime": 1690401504143,
                "Id": "298366",
                "DisplayLabel": "TEAMS - Solicitar a Desinstalação"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "TEAMS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "MENSAGERIA / COLABORAÇÃO",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Teams",
                "LastUpdateTime": 1690401503533,
                "Id": "298369",
                "DisplayLabel": "TEAMS - Solicitar a Configuração"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "TEAMS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "MENSAGERIA / COLABORAÇÃO",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Teams",
                "LastUpdateTime": 1690401503670,
                "Id": "298370",
                "DisplayLabel": "TEAMS - Solicitar a Instalação"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "TEAMS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "MENSAGERIA / COLABORAÇÃO",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Teams",
                "LastUpdateTime": 1690401504720,
                "Id": "298371",
                "DisplayLabel": "TEAMS - Estou com Problema com Teams"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "TEAMS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482828,
                "Id": "298412",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Cadastro de Magistrado"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482546,
                "Id": "298413",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (AJG - Assistência Judiciária Gratuita)</p>",
                "LastUpdateTime": 1690401428014,
                "Id": "298415",
                "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA - Cancelamento de Perfil"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482801,
                "Id": "298416",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Renovação de Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (INFOJUD da Receita Federal)</p>",
                "LastUpdateTime": 1690401482487,
                "Id": "298417",
                "DisplayLabel": "INFOJUD DA RECEITA FEDERAL - Certificado Digital"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INFOJUD DA RECEITA FEDERAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (Malote Digital)</p>",
                "LastUpdateTime": 1690401482738,
                "Id": "298418",
                "DisplayLabel": "MALOTE DIGITAL - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MALOTE DIGITAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SISBAJUD)</p>",
                "LastUpdateTime": 1690401503441,
                "Id": "298419",
                "DisplayLabel": "SISBAJUD - Liberação de Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SISBAJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SISBAJUD)</p>",
                "LastUpdateTime": 1690401503637,
                "Id": "298420",
                "DisplayLabel": "SISBAJUD - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SISBAJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (Malote Digital)</p>",
                "LastUpdateTime": 1690401482665,
                "Id": "298422",
                "DisplayLabel": "MALOTE DIGITAL - Lentidão no Sistema"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MALOTE DIGITAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (DJE)</p>",
                "LastUpdateTime": 1690401428201,
                "Id": "298423",
                "DisplayLabel": "DJE - Liberação de Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (Malote Digital)</p>",
                "LastUpdateTime": 1690401482186,
                "Id": "298424",
                "DisplayLabel": "MALOTE DIGITAL - Liberação de Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MALOTE DIGITAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (Malote Digital)</p>",
                "LastUpdateTime": 1690401482268,
                "Id": "298425",
                "DisplayLabel": "MALOTE DIGITAL - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MALOTE DIGITAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (MOVJUD)</p>",
                "LastUpdateTime": 1690401482950,
                "Id": "298426",
                "DisplayLabel": "MOVJUD - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MOVJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504260,
                "Id": "298427",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - Defensoria - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição&nbsp;de Sistemas Corporativos (MOVJUD)</p>",
                "LastUpdateTime": 1690401482325,
                "Id": "298428",
                "DisplayLabel": "MOVJUD - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MOVJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SISBAJUD)</p>",
                "LastUpdateTime": 1690401503668,
                "Id": "298429",
                "DisplayLabel": "SISBAJUD - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SISBAJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SISBAJUD)</p>",
                "LastUpdateTime": 1690401503877,
                "Id": "298430",
                "DisplayLabel": "SISBAJUD - Duvidas E Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SISBAJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SAJ INSIGTHS PG)</p>",
                "LastUpdateTime": 1690401503670,
                "Id": "298431",
                "DisplayLabel": "SAJ INSIGTHS PG - Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ INSIGTHS PG"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (DJE)</p>",
                "LastUpdateTime": 1690401427809,
                "Id": "298432",
                "DisplayLabel": "DJE - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (Malote Digital)</p>",
                "LastUpdateTime": 1690401482321,
                "Id": "298433",
                "DisplayLabel": "MALOTE DIGITAL - Duvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MALOTE DIGITAL"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503529,
                "Id": "298434",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Restauração da Senha - Defensoria - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503344,
                "Id": "298435",
                "DisplayLabel": "SIVEC/INTINFO - Erro (Réu Preso)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (CRC JUD)</p>",
                "LastUpdateTime": 1690401428001,
                "Id": "298436",
                "DisplayLabel": "CRC JUD - Configuração"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CRC JUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (PRECWEB)</p>",
                "LastUpdateTime": 1690401482701,
                "Id": "298437",
                "DisplayLabel": "PRECWEB - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PRECWEB"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (PRECWEB)</p>",
                "LastUpdateTime": 1690401482855,
                "Id": "298438",
                "DisplayLabel": "PRECWEB - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PRECWEB"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SISBAJUD)</p>",
                "LastUpdateTime": 1690401503671,
                "Id": "298439",
                "DisplayLabel": "SISBAJUD - Lentidão no Sistema"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SISBAJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504762,
                "Id": "298440",
                "DisplayLabel": "SIVEC/INTINFO - Alteração"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504176,
                "Id": "298441",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Restauração da Senha - CIC - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (MOVJUD)</p>",
                "LastUpdateTime": 1690401481075,
                "Id": "298442",
                "DisplayLabel": "MOVJUD - Liberação de Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MOVJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (DJE)</p>",
                "LastUpdateTime": 1690401426735,
                "Id": "298443",
                "DisplayLabel": "DJE - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos",
                "LastUpdateTime": 1690401482732,
                "Id": "298444",
                "DisplayLabel": "PJE - Liberação de Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (PRECWEB)</p>",
                "LastUpdateTime": 1690401483232,
                "Id": "298445",
                "DisplayLabel": "PRECWEB - Configuração"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PRECWEB"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (CRC JUD)</p>",
                "LastUpdateTime": 1690401427444,
                "Id": "298446",
                "DisplayLabel": "CRC JUD - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CRC JUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503997,
                "Id": "298447",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - SAP - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos",
                "LastUpdateTime": 1690401482549,
                "Id": "298448",
                "DisplayLabel": "PJE - Lentidão no Sistema"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos",
                "LastUpdateTime": 1690401483248,
                "Id": "298449",
                "DisplayLabel": "PJE - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (MOVJUD)</p>",
                "LastUpdateTime": 1690401483127,
                "Id": "298450",
                "DisplayLabel": "MOVJUD - Duvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "MOVJUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (PRECWEB)</p>",
                "LastUpdateTime": 1690401482521,
                "Id": "298451",
                "DisplayLabel": "PRECWEB - Liberação de Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PRECWEB"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (Portal do Servidor)</p>",
                "LastUpdateTime": 1690401482210,
                "Id": "298452",
                "DisplayLabel": "PORTAL DO SERVIDOR - Frase de Segurança"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DO SERVIDOR"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503106,
                "Id": "298453",
                "DisplayLabel": "SIVEC/INTINFO - Erro na Folha de Antecedentes"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504315,
                "Id": "298454",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Restauração da Senha - TJ - Magistrados Intinfo"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504175,
                "Id": "298455",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Restauração da Senha - TJ - Assistente Jurídico/Judiciário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504303,
                "Id": "298456",
                "DisplayLabel": "SIVEC/INTINFO - Erro/ Falha no Sistema"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos",
                "LastUpdateTime": 1690401482550,
                "Id": "298457",
                "DisplayLabel": "PJE - Instalação e Configuração"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (CRC JUD)</p>",
                "LastUpdateTime": 1690401427072,
                "Id": "298458",
                "DisplayLabel": "CRC JUD - Indisponibilidade"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CRC JUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503344,
                "Id": "298459",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Restauração da Senha - MP - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503511,
                "Id": "298460",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Restauração da Senha - MP - Nível Coordenador"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (PRECWEB)</p>",
                "LastUpdateTime": 1690401482799,
                "Id": "298461",
                "DisplayLabel": "PRECWEB - Lentidão no Sistema"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PRECWEB"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SAJ INSIGTHS PG)</p>",
                "LastUpdateTime": 1690401503365,
                "Id": "298462",
                "DisplayLabel": "SAJ INSIGTHS PG - Orientações"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ INSIGTHS PG"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503334,
                "Id": "298463",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - MP - Nível Coordenador"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503669,
                "Id": "298464",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - CIC - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (PRECWEB)</p>",
                "LastUpdateTime": 1690401483302,
                "Id": "298465",
                "DisplayLabel": "PRECWEB - Dúvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PRECWEB"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504309,
                "Id": "298466",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Restauração da Senha - Casos Especiais (Estagiários) - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504212,
                "Id": "298467",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - TJ - Casos Especiais (Estagiários) - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503496,
                "Id": "298468",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - TJ - Nível Coordenador"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401502721,
                "Id": "298469",
                "DisplayLabel": "SIVEC/INTINFO - Erro na Emissão de Documento"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (CRC JUD)</p>",
                "LastUpdateTime": 1690401428203,
                "Id": "298470",
                "DisplayLabel": "CRC JUD - Liberação De Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CRC JUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição&nbsp;de Sistemas Corporativos (Portal do Servidor)</p>",
                "LastUpdateTime": 1690401483293,
                "Id": "298471",
                "DisplayLabel": "PORTAL DO SERVIDOR - Acesso"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DO SERVIDOR"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (DJE)</p>",
                "LastUpdateTime": 1690401428200,
                "Id": "298472",
                "DisplayLabel": "DJE - Duvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504136,
                "Id": "298473",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - TJ -  Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (CRC JUD)</p>",
                "LastUpdateTime": 1690401427395,
                "Id": "298474",
                "DisplayLabel": "CRC JUD - Lentidão No Sistema"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CRC JUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401503888,
                "Id": "298475",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - TJ - Magistrados Intinfo"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (CRC JUD)</p>",
                "LastUpdateTime": 1690401427771,
                "Id": "298476",
                "DisplayLabel": "CRC JUD - Dúvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CRC JUD"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401502752,
                "Id": "298477",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação de Usuário - MP - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos",
                "LastUpdateTime": 1690401482562,
                "Id": "298478",
                "DisplayLabel": "PJE - Duvidas e Orientações Gerais"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504116,
                "Id": "298479",
                "DisplayLabel": "SIVEC/INTINFO - Cancelamento"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504057,
                "Id": "298480",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de Criação da Senha - TJ - Assistente Jurídico/Judiciário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SAJ INSIGTHS PG)</p>",
                "LastUpdateTime": 1690401503706,
                "Id": "298481",
                "DisplayLabel": "SAJ INSIGTHS PG - Filtro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ INSIGTHS PG"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos",
                "LastUpdateTime": 1690401483453,
                "Id": "298482",
                "DisplayLabel": "PJE - Erro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PJE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (AJG - Assistência Judiciária Gratuita)</p>",
                "LastUpdateTime": 1690401428152,
                "Id": "298501",
                "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA - Cadastramento - Escrivão (Supervisor, Diretor Ou Coordenador)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AJG- ASSISTÊNCIA JUDICIÁRIA GRATUITA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Java Runtime",
                "LastUpdateTime": 1690401483359,
                "Id": "298515",
                "DisplayLabel": "JAVA RUNTIME - Solicitar a Instalação do Java"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "JAVA RUNTIME"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Java Runtime",
                "LastUpdateTime": 1690401482748,
                "Id": "298516",
                "DisplayLabel": "JAVA RUNTIME - Solicitar a Atualização do Java"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "JAVA RUNTIME"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Internet (Navegadores)",
                "LastUpdateTime": 1690401483274,
                "Id": "298520",
                "DisplayLabel": "INTERNET (NAVEGADORES) - Estou com problema com Navegador"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INTERNET (NAVEGADORES)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Internet (Navegadores)",
                "LastUpdateTime": 1690401481897,
                "Id": "298521",
                "DisplayLabel": "INTERNET (NAVEGADORES) - Solicitar a Configuração do Navegador"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INTERNET (NAVEGADORES)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Leitor de PDF",
                "LastUpdateTime": 1690401482529,
                "Id": "298522",
                "DisplayLabel": "LEITOR DE PDF (ADOBE) - Solicitar a Instalação do Conversor PDF"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LEITOR DE PDF (ADOBE)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Internet (Navegadores)",
                "LastUpdateTime": 1690401483189,
                "Id": "298523",
                "DisplayLabel": "INTERNET (NAVEGADORES) - Solicitar a Atualização do Navegador"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INTERNET (NAVEGADORES)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Internet (Navegadores)",
                "LastUpdateTime": 1690401482191,
                "Id": "298524",
                "DisplayLabel": "INTERNET (NAVEGADORES) - Solicitar a Instalação do Navegador"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "INTERNET (NAVEGADORES)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Leitor de PDF",
                "LastUpdateTime": 1690401482052,
                "Id": "298525",
                "DisplayLabel": "LEITOR DE PDF (ADOBE) - Solicitar a Instalação de Leitor de PDF (Adobe)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LEITOR DE PDF (ADOBE)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição do Pacote Office",
                "LastUpdateTime": 1690401482053,
                "Id": "298526",
                "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK) - Solicitar a Configuração do Office (Word / Excel / PowerPoint / Outlook)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição do Pacote Office",
                "LastUpdateTime": 1690401483330,
                "Id": "298527",
                "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK) - Solicitar a Instalação do Office (Word / Excel / PowerPoint / Outlook)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição do Pacote Office",
                "LastUpdateTime": 1690401483193,
                "Id": "298528",
                "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK) - Solicitar a Ativação do Office (Word / Excel / PowerPoint / Outlook)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição do Pacote Office",
                "LastUpdateTime": 1690401481897,
                "Id": "298529",
                "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK) - Estou com problema com o Office (Word / Excel / PowerPoint / Outlook)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição do Pacote Office",
                "LastUpdateTime": 1690401482865,
                "Id": "298530",
                "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK) - Estou com dúvidas sobre o Pacote Office (Word / Excel / PowerPoint / Outlook)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição do Pacote Office",
                "LastUpdateTime": 1690401483161,
                "Id": "298531",
                "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK) - Estou com Problema com BOOKINGS"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PACOTE OFFICE (WORD / EXCEL / POWERPOINT / OUTLOOK)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição do NERO",
                "LastUpdateTime": 1690401482665,
                "Id": "298532",
                "DisplayLabel": "LEITOR DE PDF (ADOBE) - Estou com problema com Leitor de PDF (Adobe)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LEITOR DE PDF (ADOBE)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de Rede",
                "LastUpdateTime": 1690401504136,
                "Id": "298536",
                "DisplayLabel": "REDE - Rede Oscilando"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "REDE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de VPN",
                "LastUpdateTime": 1690401503504,
                "Id": "298541",
                "DisplayLabel": "VPN - Problema com a VPN"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "VPN"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de VDI",
                "LastUpdateTime": 1690401504143,
                "Id": "298542",
                "DisplayLabel": "VDI - Solicitar a Configuração de VDI"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "VDI"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Telefonia (TELEFONIA FIXA / VOIP)</p>",
                "LastUpdateTime": 1690401503884,
                "Id": "298544",
                "DisplayLabel": "TELEFONIA FIXA / VOIP - Solicitar Configuração de VOIP"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "TELEFONIA FIXA / VOIP"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de VPN",
                "LastUpdateTime": 1690401504689,
                "Id": "298546",
                "DisplayLabel": "VPN - Configuração da VPN"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "VPN"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de VDI",
                "LastUpdateTime": 1690401503671,
                "Id": "298548",
                "DisplayLabel": "VDI - Solicitação de Acesso à VDI"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "VDI"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de VPN",
                "LastUpdateTime": 1690401504763,
                "Id": "298551",
                "DisplayLabel": "VPN - Solicitação de Acesso à VPN"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "VPN"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "Use esta solicitação para relatar falhas ou abrir uma requisição de VDI",
                "LastUpdateTime": 1690401503998,
                "Id": "298552",
                "DisplayLabel": "VDI - Problema com VDI"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "VDI"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: LOTAÇÃO/SENHA</p><p>Criação/Alteração de Lotação de Terceiros</p>",
                "LastUpdateTime": 1690401363605,
                "Id": "303186",
                "DisplayLabel": "Criação/Alteração de Lotação de Terceiros"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LOTAÇÃO/SENHA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: LOTAÇÃO/SENHA</p><p>Alteração de Lotação de Magistrado</p>",
                "LastUpdateTime": 1690401363544,
                "Id": "303279",
                "DisplayLabel": "Alteração de Lotação de Magistrado"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LOTAÇÃO/SENHA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: LOTAÇÃO/SENHA</p><p>Criação/Alteração de Lotação de Funcionários</p>",
                "LastUpdateTime": 1690401427931,
                "Id": "303280",
                "DisplayLabel": "Criação/Alteração de Lotação de Funcionários"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LOTAÇÃO/SENHA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ</p><p><strong>SERVIÇO</strong>: LOTAÇÃO/SENHA</p><p>Fornecimento de Nova Senha</p>",
                "LastUpdateTime": 1690401448572,
                "Id": "303281",
                "DisplayLabel": "Fornecimento de Nova Senha"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LOTAÇÃO/SENHA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>Criação/Alteração de Lotação de Funcionários.</p>",
                "LastUpdateTime": 1690401482325,
                "Id": "346874",
                "DisplayLabel": "Lotação/Senha - 1 *** NEW *** Criação/Alteração de Lotação de Funcionários"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LOTAÇÃO/SENHA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>Alteração de Lotação de Magistrado.</p>",
                "LastUpdateTime": 1690401482724,
                "Id": "509618",
                "DisplayLabel": "Lotação/Senha - 2 *** NEW *** Alteração de Lotação de Magistrado"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LOTAÇÃO/SENHA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>Criação/Alteração de Lotação de Terceiros.</p>",
                "LastUpdateTime": 1690401482100,
                "Id": "509619",
                "DisplayLabel": "Lotação/Senha - 3 *** NEW *** Criação/Alteração de Lotação de Terceiros"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "LOTAÇÃO/SENHA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS. Cadastro, alocação e alteração de perfil.&nbsp;</p>",
                "LastUpdateTime": 1690401482127,
                "Id": "727326",
                "DisplayLabel": "PORTAL DE CUSTAS - Cadastro, alocação e alteração de perfil"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS. Conta judicial não disponível no Portal de Custas</p>",
                "LastUpdateTime": 1690401483178,
                "Id": "727892",
                "DisplayLabel": "PORTAL DE CUSTAS - Conta judicial não disponível no Portal de Custas"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS.&nbsp;Emissão de guia de custas (DARE) e depósito judicial</p>",
                "LastUpdateTime": 1690401483231,
                "Id": "728474",
                "DisplayLabel": "PORTAL DE CUSTAS - Emissão de guia de custas (DARE) e depósito judicial"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS.Emissão de MLE</p>",
                "LastUpdateTime": 1690401482322,
                "Id": "728764",
                "DisplayLabel": "PORTAL DE CUSTAS - Emissão de MLE"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS. Transferência de contas entre processos</p>",
                "LastUpdateTime": 1690401483127,
                "Id": "729040",
                "DisplayLabel": "PORTAL DE CUSTAS - Transferência de contas entre processos"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS. Erros e intermitência no sistema</p>",
                "LastUpdateTime": 1690401482294,
                "Id": "729090",
                "DisplayLabel": "PORTAL DE CUSTAS - Erros e intermitência no sistema"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS. Guia de Pena de Prestação Pecuniária</p>",
                "LastUpdateTime": 1690401482327,
                "Id": "729380",
                "DisplayLabel": "PORTAL DE CUSTAS - Guia de Pena de Prestação Pecuniária"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS. Permissão para o processo negada</p>",
                "LastUpdateTime": 1690401483135,
                "Id": "729554",
                "DisplayLabel": "PORTAL DE CUSTAS - Permissão para o processo negada"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição do PORTAL DE CUSTAS. Queima da guia DARE (procedimentos para queima e cancelamento da queima)</p>",
                "LastUpdateTime": 1690401482721,
                "Id": "729721",
                "DisplayLabel": "PORTAL DE CUSTAS - Queima da guia DARE (procedimentos para queima e cancelamento da queima)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DE CUSTAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos. EAD MOODLE - CORREGEDORIA</p>",
                "LastUpdateTime": 1690401427419,
                "Id": "1038489",
                "DisplayLabel": "EAD MOODLE - Corregedoria"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "EAD MOODLE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos. EAD MOODLE - SGP (Secretaria de Gestão de Pessoas)</p>",
                "LastUpdateTime": 1690401428202,
                "Id": "1038673",
                "DisplayLabel": "EAD MOODLE - SGP (Secretaria de Gestão de Pessoas)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "EAD MOODLE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos. EAD MOODLE - EPM (Escola Paulista de Magistratura)&nbsp;</p>",
                "LastUpdateTime": 1690401427397,
                "Id": "1038678",
                "DisplayLabel": "EAD MOODLE - EPM (Escola Paulista de Magistratura)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "EAD MOODLE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Criação de oferta para melhoria do processo interno (SMAX)</p>",
                "LastUpdateTime": 1690401503770,
                "Id": "1288537",
                "DisplayLabel": "SMAX - Melhoria"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SMAX"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Utilize essa solicitação para relatar problemas ou retirar dúvidas referente ao SMAX.</p>",
                "LastUpdateTime": 1690401503544,
                "Id": "1288538",
                "DisplayLabel": "SMAX - Suporte"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SMAX"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Portal da Magistratura para consulta de informações da vida funcional</p>",
                "LastUpdateTime": 1690401482655,
                "Id": "1288569",
                "DisplayLabel": "PORTAL DA MAGISTRATURA - DADOS VIDA FUNCIONAL"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DA MAGISTRATURA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Portal da Magistratura para inscrição eletrônica ao concurso de promoção e remoção</p>",
                "LastUpdateTime": 1690401482092,
                "Id": "1288771",
                "DisplayLabel": "PORTAL DA MAGISTRATURA - CONCURSOS"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DA MAGISTRATURA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Portal da Magistratura para consulta de informações, comunicados e legislação de RH de Magistrados.</p>",
                "LastUpdateTime": 1690401481737,
                "Id": "1289033",
                "DisplayLabel": "PORTAL DA MAGISTRATURA - COMUNICADOS"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DA MAGISTRATURA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Portal da Magistratura para consulta de dados pessoais</p>",
                "LastUpdateTime": 1690401481910,
                "Id": "1289037",
                "DisplayLabel": "PORTAL DA MAGISTRATURA - DADOS PESSOAIS"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DA MAGISTRATURA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Portal da Magistratura para consulta de designações</p>",
                "LastUpdateTime": 1690401482164,
                "Id": "1289038",
                "DisplayLabel": "PORTAL DA MAGISTRATURA - DESIGNAÇÕES"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PORTAL DA MAGISTRATURA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "<p>Use essa solicitação para solicitar ativação da autenticação multifator (MFA)&nbsp;</p>",
                "LastUpdateTime": 1690401427825,
                "Id": "1688918",
                "DisplayLabel": "AUTENTICAÇÃO MULTIFATOR (MFA) - SOLICITAR ATIVAÇÃO"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AUTENTICAÇÃO MULTIFATOR (MFA)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SOFTWARES",
                "Description": "<p>Use essa solicitação para solicitar configuração da autenticação multifator (MFA)&nbsp;</p>",
                "LastUpdateTime": 1690401427864,
                "Id": "1689298",
                "DisplayLabel": "AUTENTICAÇÃO MULTIFATOR (MFA) - SOLICITAR CONFIGURAÇÃO"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AUTENTICAÇÃO MULTIFATOR (MFA)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Requisição de serviço movimentação de hardwares, como impressoras, desktop, switches, e entre outros.</p>",
                "LastUpdateTime": 1690401427376,
                "Id": "1894374",
                "DisplayLabel": "ACOMPANHAMENTO TÉCNICO - desinstalação, transporte e reinstalação de hardware"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACOMPANHAMENTO TÉCNICO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Requisição de serviço para acompanhamento de operadora de serviços de internet para manobra de link.</p>",
                "LastUpdateTime": 1690401503708,
                "Id": "1894612",
                "DisplayLabel": "REDE - Acompanhamento para manobra de link"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "REDE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Requisição de suporte técnico para atendimento de ordem de serviço.</p>",
                "LastUpdateTime": 1690401427822,
                "Id": "1894663",
                "DisplayLabel": "ACOMPANHAMENTO TÉCNICO - Acompanhamento/verificação técnica para execução de OS"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACOMPANHAMENTO TÉCNICO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Requisição de suporte técnico para atendimento de ordem de serviço.</p>",
                "LastUpdateTime": 1690401427019,
                "Id": "1894792",
                "DisplayLabel": "ACOMPANHAMENTO TÉCNICO - Acompanhamento/verificação para sessão de juri"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACOMPANHAMENTO TÉCNICO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Requisição de suporte tecnico para atendimento de ordem de serviço.</p>",
                "LastUpdateTime": 1690401427823,
                "Id": "1895324",
                "DisplayLabel": "ACOMPANHAMENTO TÉCNICO - Acompanhamento/verificação técnica para servidores SSDS/Riverbed"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACOMPANHAMENTO TÉCNICO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Requisição de suporte tecnico para atendimento de ordem de serviço.</p>",
                "LastUpdateTime": 1690401427823,
                "Id": "1895923",
                "DisplayLabel": "ACOMPANHAMENTO TÉCNICO - Acompanhar instalação de fibra óptica"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACOMPANHAMENTO TÉCNICO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Requisição de suporte técnico para atendimento de ordem de serviço.</p>",
                "LastUpdateTime": 1690401427709,
                "Id": "1897336",
                "DisplayLabel": "ACOMPANHAMENTO TÉCNICO - Acompanhamento/verificação técnica para VOIP"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "ACOMPANHAMENTO TÉCNICO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use essa solicitação para realizar atualização, criação, desativação e liberação de acesso de componentes do catálogo. (Serviço/ Oferta e Script).</p><p>Caso seja necessário atualizar, criar,&nbsp;desativar ou liberar acesso para&nbsp;mais de um componente, favor incluir todas as informações no campo descrição ou anexar o template.</p>",
                "LastUpdateTime": 1690401427838,
                "Id": "1990998",
                "DisplayLabel": "CATÁLOGO DE SERVIÇO -  Atualização/Criação/Desativação/Liberação de componentes do catálogo"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CATÁLOGO DE SERVIÇO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use essa solicitação para atualizar/criar/desativar uma categoria no catálogo de serviços.</p><p><br>\nCaso seja necessário atualizar/criar/desativar mais de uma categoria, favor incluir todas as informações no campo descrição ou anexar o template</p>",
                "LastUpdateTime": 1690401427068,
                "Id": "1991527",
                "DisplayLabel": "CATÁLOGO DE SERVIÇO -  Atualização/Criação/Desativação de categorias do catálogo"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CATÁLOGO DE SERVIÇO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>Dúvidas sobre o andamento do seu processo, telefone de contato ou dúvidas sobre serviços jurídicos prestado pelo tribunal de justiça de São Paulo</p>",
                "LastUpdateTime": 1690401482699,
                "Id": "2150502",
                "DisplayLabel": "Pessoa Física - Dúvidas Jurídicas"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AUTOATENDIMENTO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>dúvida é sobre o funcionamento dos fóruns durante a pandemia do corona vírus</p>",
                "LastUpdateTime": 1690401482687,
                "Id": "2150507",
                "DisplayLabel": "Pessoa Física - Horário de funcionamento TJSP"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AUTOATENDIMENTO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>Integração e abertura de chamado pelo 0800, para demandas de erros generalizados, e posterior reclassificação pelo 1° nível.</p>",
                "LastUpdateTime": 1690401448602,
                "Id": "2151477",
                "DisplayLabel": "Erro global - Autoatendimento"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AUTOATENDIMENTO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>Dúvidas sobre o andamento do seu processo, telefone de contato ou dúvidas sobre serviços jurídicos prestado pelo tribunal de justiça de São Paulo</p>",
                "LastUpdateTime": 1690401482717,
                "Id": "2152968",
                "DisplayLabel": "Pessoa Física - Dúvidas Jurídicas"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "AUTOATENDIMENTO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>DESMEMBRAMENTO DAS DESIGNAÇÕES DO PLANTÃO PARA OS MAGISTRADOS</p>",
                "LastUpdateTime": 1690401482096,
                "Id": "2210486",
                "DisplayLabel": "PLANTÃO MAGISTRADOS"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PLANTÃO MAGISTRADOS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p>DESMEMBRAMENTO DAS DESIGNAÇÕES DO SEMA PARA OS MAGISTRADOS</p>",
                "LastUpdateTime": 1690401503295,
                "Id": "2211682",
                "DisplayLabel": "PUBLICAÇÃO SEMA"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PUBLICAÇÃO SEMA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Serviços de rede, englobando reparo, testes, organização de cabos ou retirada de cabos.</p>",
                "LastUpdateTime": 1690401503182,
                "Id": "2255384",
                "DisplayLabel": "Rede – Cabeamento / Ponto de rede (reparo, testes, organização, retirada)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "REDE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "INFRAESTRUTURA",
                "Description": "<p>Apoio técnico para realização de testes, reparo ou movimentação de rack ou switch.</p>",
                "LastUpdateTime": 1690401504770,
                "Id": "2255413",
                "DisplayLabel": "Rede - Rack / Switch (teste, reparo, movimentação)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "REDE"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>USE ESTA SOLICITAÇÃO PARA QUALQUER ALTERAÇÃO REFERENTE AOS MODELOS DE MUDANÇA (GMUD) NA FERRAMENTA&nbsp;SMAX</p>",
                "LastUpdateTime": 1690446003025,
                "Id": "2435382",
                "DisplayLabel": "ALTERAÇÃO REFERENTE AOS MODELOS DE MUDANÇA"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SMAX"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>CONECTOR ÓPTICO COM DEFEITO OU QUEBRADO SEM ACESSO A REDE&nbsp;</p><p>KIT COM 10 CONECTORES OPTICOS DE CAMPO FURUKAWA &nbsp; SM SC-APC EZ CONNECTOR PARA CABOS FLAT 1.6X2MM E 3X2MM</p>",
                "LastUpdateTime": 1690401426925,
                "Id": "3282974",
                "DisplayLabel": "CONECTOR ÓPTICO"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "GPON Fibra"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>MODEM GPON ÓPTICO COM DEFEITO ( NÃO LIGA FONTE COM DEFEITO &nbsp;OU NÃO CONECTA COM A INTERNET )</p><p>MODEM ÓPTICO GPON (ONT) MODELO FURUKAWA LD110-44B, EQUIPAMENTO COM 4 INTERFACES GIGA ETHERNET E QUATRO INTERFACES VOIP &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>",
                "LastUpdateTime": 1690401483722,
                "Id": "3283441",
                "DisplayLabel": "MODEM GPON ONT"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "GPON Fibra"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>FIBRA ÓPTICA SEM SINAL OU DANIFICADA&nbsp;</p><p>CAIXA DE CABO ÓPTICO FURUKAWA ( CODIGO: 17850058 )</p>",
                "LastUpdateTime": 1690401448769,
                "Id": "3284085",
                "DisplayLabel": "FIBRA ÓPTICA"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "GPON Fibra"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Use esta solicitação para relatar falhas ou abrir uma requisição de Sistemas Corporativos (SIVEC/INTINFO)</p>",
                "LastUpdateTime": 1690401504077,
                "Id": "3869455",
                "DisplayLabel": "SIVEC/INTINFO - Solicitação de restauração de senha - TJ - Nível Usuário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SIVEC/INTINFO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SISTEMAS CORPORATIVOS",
                "Description": "<p>Criação de oferta&nbsp;e de fluxo para criação, desativação, atualização de usuário&nbsp;e alteração de nomenclatura de Grupos Solucionadores dentro da ferramenta SMAX</p>",
                "LastUpdateTime": 1690401427428,
                "Id": "4031244",
                "DisplayLabel": "CATÁLOGO DE SERVIÇOS - Atualização/Criação/Desativação/Liberação de Filas (GSE’s)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "CATÁLOGO DE SERVIÇO"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA:</strong> SAJ SG5<br>\n<strong>SERVIÇO:</strong>&nbsp;Protocolo Digital (SG5)</p><p></p><p>Módulo Andamento do sistema Protocolo Digital (SG5).</p><p></p><pre>Movimentação (Protocolo digital), Recebimento de Devolução de Protocolo, Remessa (Protocolo digital).</pre>",
                "LastUpdateTime": 1690401427443,
                "Id": "4119051",
                "DisplayLabel": "Andamento"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "Protocolo Digital (SG5)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA:</strong> SAJ SG5<br>\n<strong>SERVIÇO:</strong>&nbsp;Protocolo Digital (SG5)</p><p></p><p>Módulo Consulta do sistema Protocolo Digital (SG5).</p><p></p><pre>Auditoria (Protocolo digital), Protocolos.</pre>",
                "LastUpdateTime": 1690401427933,
                "Id": "4119062",
                "DisplayLabel": "Consulta"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "Protocolo Digital (SG5)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA:</strong> SAJ SG5<br>\n<strong>SERVIÇO:</strong>&nbsp;Protocolo Digital (SG5)</p><p></p><p>Módulo Apoio&nbsp;do sistema Protocolo Digital (SG5).</p><p></p><pre>Alteração de Senha (Protocolo digital), Hora do Servidor, Opções de Visualização.</pre>",
                "LastUpdateTime": 1690401363607,
                "Id": "4119312",
                "DisplayLabel": "Apoio - PROTOCOLO DIGITAL (SG5)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "Protocolo Digital (SG5)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA:</strong> SAJ SG5<br>\n<strong>SERVIÇO:</strong>&nbsp;Protocolo Digital (SG5)</p><p></p><p>Módulo Relatórios&nbsp;do sistema Protocolo Digital (SG5).</p><p></p><pre>Estatísticos - Produtividade, Remessa de protocolos.</pre>",
                "LastUpdateTime": 1690401503688,
                "Id": "4119321",
                "DisplayLabel": "Relatórios"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "Protocolo Digital (SG5)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Ajuda&nbsp;do sistema SG5.</p><pre>Reemissão do Comprovante de Remessa, Relatórios.</pre>",
                "LastUpdateTime": 1690401363429,
                "Id": "4119322",
                "DisplayLabel": "Ajuda"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Carga&nbsp;do sistema SG5.</p><pre>Cancelamento (Carga SG), Consulta de Carga (SG), Consulta de Lotes Controlados pelo sistema, Consulta de Prazo de Devolução de Remessa, Consulta de Processos em Carga, Devolução de Protocolos, Recebimento (SG), Recebimento sem remessa (SG), Reemissão do Comprovante de Remessa (Carga SG), Remessa (Carga SG).</pre>",
                "LastUpdateTime": 1690401363431,
                "Id": "4119381",
                "DisplayLabel": "Carga - SG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Emissão de Expediente&nbsp;do sistema SG5.</p><pre>Cadastro de Autotextos (SG), Cadastro de Modelos de Documento (SG), Cancelamento ou Retificação de Documentos, Configurações do Usuário (SG), Confirmação de Movimentação (SG), Documentos Recentes (SG), Editor de Documentos (SG), Emissão de Documentos (Expediente SG), Gerenciador de Arquivos (SG).</pre>",
                "LastUpdateTime": 1690401363026,
                "Id": "4119394",
                "DisplayLabel": "Emissão de Expediente - SG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA:</strong> SAJ SG5<br>\n<strong>SERVIÇO:</strong>&nbsp;Protocolo Digital (SG5)</p><p></p><p>Módulo Protocolo&nbsp;do sistema Protocolo Digital (SG5).</p><p></p><pre>Contingências, Esqueci Minha Senha, Identificação do Usuário (Protocolo digital), Petições Iniciais e Intermediárias, Sair (Protocolo digital), Validação da Autenticação Mecânica.</pre>",
                "LastUpdateTime": 1690401503539,
                "Id": "4119514",
                "DisplayLabel": "Protocolo - PROTOCOLO DIGITAL (SG5)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "Protocolo Digital (SG5)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Apoio do sistema SG5.</p><pre>Ajustar Pessoa Controlada, Calendário, Configuração de Estação, Corrige Processo no Fluxo, Documentos em Edição, Importação SG3, Importação de Documentos, Programação de plantão (Apoio), Suspensão de Representantes.</pre>",
                "LastUpdateTime": 1690401363429,
                "Id": "4119527",
                "DisplayLabel": "Apoio - SG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Distribuição&nbsp;do sistema SG5.</p><pre>Alteração da Relatoria, Cancelamento da Distribuição do processo, Compensação Manual de Peso, Compensação Manual de Peso por Órgão Julgador, Configuração do Estudo Automático, Encaminhamento para Outra Seção ou Subseção, Encaminhamento para Outra Seção ou Subseção – Cancelamento, Estudo da Prevenção, Estudo da Prevenção em Lote, Lotes de Distribuição, Medidas Urgentes – Relator Afastado, Preparação da Distribuição, Redistribuição Entre Instalações – Cancelamento, Redistribuição Entre Instalações – Encaminhamento, Redistribuição Entre Instalações – Recebimento, Redistribuição Excepcional, Registro do Encaminhamento, Resultado do Estudo Automático, Transferência de Processos Entre Magistrados (SG).</pre>",
                "LastUpdateTime": 1690401427811,
                "Id": "4119570",
                "DisplayLabel": "Distribuição"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Cadastro do sistema SG5.</p><pre>Alteração do Número Unificado, Cancelamento de Processo, Configuração para atribuição de Cadastradores, Correção de Classe (SG), Custas, Desfazer Cancelamento de Processo, Digitalização de Peças Processuais (SG), Histórico de Partes (SG), Importação de Processos Físicos em Bloco, Incidentes e Petições Avulsas, Materialização de Processos Virtuais (SG), Partes e Representantes (SG), Perguntas do Termo de Análise, Pessoas (Cadastro Controlado) SG, Petições Iniciais Aguardando Cadastro (Cadastro SG), Petições Intermediárias Aguardando Cadastro (Cadastro SG), Preliminar de Recurso Físico, Tornar Processo Digital, Unificação de Partes e Representantes, Validação dos Dados do Processos, Valores para Portes e Remessa.</pre>",
                "LastUpdateTime": 1690401427761,
                "Id": "4119926",
                "DisplayLabel": "Cadastro"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Julgamento Virtual&nbsp;do sistema SG5.</p><p></p><pre>Alterar Composição de Julgamento Virtual, Assinatura dos Documentos - Julgamento Virtual, Cancelamento ou Tornar sem Efeito do Julgamento Virtual, Criação de Documentos do Julgamento Virtual, Iniciar Julgamento Virtual, Retirar Processo do Julgamento Virtual, Votação de Julgamento Virtual.</pre>",
                "LastUpdateTime": 1690401482824,
                "Id": "4120339",
                "DisplayLabel": "Julgamento Virtual"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Pasta Digital do sistema SG5.</p><pre>Consulta de pasta SG, Integração PG, Liberar documentos nos autos digitais.</pre>",
                "LastUpdateTime": 1690401466621,
                "Id": "4120344",
                "DisplayLabel": "Pasta Digital - SG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Julgamento&nbsp;do sistema SG5.</p><pre>Afastamento de Conciliador, Agendamento de Pauta, Audiência de Conciliação por Sala, Cancelar Publicação de Pauta da Sessão de Julgamento, Configuração da Sessão de Julgamento, Decisões-Padrão, Passagem de Autos, Pauta de Audiência de Conciliação – Corrido, Pauta de Audiência de Conciliação – Tabelado, Pauta de Julgamento, Penas por Improbidade Administrativa (Julgamento), Registro de Solicitação de Conciliação, Relatório de Afastamento, Sessão de Julgamento.</pre>",
                "LastUpdateTime": 1690401482721,
                "Id": "4120605",
                "DisplayLabel": "Julgamento"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Plantão Judiciário&nbsp;do sistema SG5.</p><pre>Liberar decisões para consulta, Programação de plantão (Plantão judiciário).</pre>",
                "LastUpdateTime": 1690401466061,
                "Id": "4120802",
                "DisplayLabel": "Plantão Judiciário - SG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Publicação do sistema SG5.</p><pre>Ata da Distribuição, Decisões, Despachos, Distribuídos, Durante a sessão, Entrados, Expedientes (Publicação), Sem sessão.</pre>",
                "LastUpdateTime": 1690401504167,
                "Id": "4120815",
                "DisplayLabel": "Publicação"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Cadastro e distribuição do sistema PG5.</p><pre>Armas e Bens, Cadastro de PEC, Cartas Precatórias, Contatos, Distribuição de Processos em Lote, Partes e Representantes (PG), Pessoas (Cadastro Controlado) PG, Petições Iniciais Aguardando Cadastro (Cadastro PG), Petições Intermediárias Aguardando Cadastro (Cadastro PG), Petições Intermediárias e Incidentes Processuais (Cadastro), Processos Encaminhados Pelas Delegacias (Contingência), Processos Excepcionais, Processos Excepcionais (Outros Sistemas), Processos Gerais, Redistribuição entre Foros - Cancelamento, Redistribuição entre Foros - Encaminhamento, Redistribuição entre Foros - Recebimento, Redistribuição entre Vagas, Redistribuição entre Varas, Redistribuição para Vara Preventa, Solicitação de assistência judiciária, Validação do Processo.</pre>",
                "LastUpdateTime": 1690401427749,
                "Id": "4120884",
                "DisplayLabel": "Cadastro e distribuição"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo AIP do sistema PG5.</p><pre>Acompanhamento, Apoio (AIP), Apresentação, Apresentação por Leitura Biométrica, Cadastro de PEC (AIP), Cadastro de Roteiros de Penas, Cancelamento de Roteiros de Penas, Carta de Guia, Comunicação ao TRE, Condenação Criminal, Cálculo de pena, Envio de Guias de Execução, Exclusão de PEC, Extinção de Punibilidade, Fiança, Fichado Réu, Guia de Execução (AIP), Histórico de Partes (PG), Histórico de Partes em Lote, Histórico de partes - Soltura de réu preso, Inclusão ou Exclusão do Rol de Culpados, Indulto ou Comutação, Infrações Penais, Interdição, Medida de Segurança, Multa, Painel de Acompanhamento, Pecuniária-Doação, Pecuniária - Espécie, Prestação, Previsão de Livramento Condicional, Previsão de Prescrição, Previsão de Progressão de Regime, Previsão de Saída Temporária, Previsão de Tempo Máximo de Impedimento ou Suspensão, Previsão de Término de Pena, Reativação de Roteiros de Penas Cancelados, Relatório de processos com prisões não consideradas, Rol Estadual da Lei 9.099,Rol de Culpados, Rol de Processos Suspensos, Roteiro de Penas, Réus Presos ou Aguardando Internação, Réus Presos ou Provisoriamente, Réus em Liberdade, Sigilo, Utilitários.</pre>",
                "LastUpdateTime": 1690401428041,
                "Id": "4121407",
                "DisplayLabel": "AIP"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Carga do sistema PG5.</p><pre>Cancelamento (Carga PG), Consulta de Carga (PG), Consulta de Prazo de Devolução de Remessas, Consulta de Processos e Petições em Carga, Ofícios de Cobrança, Recebimento (PG), Recebimento sem remessa (PG), Reemissão do Comprovante de Remessa (Carga PG), Relatórios de carga, Remessa (Carga PG), Remessa ao Distrito Policial, Remessa ao Ministério Público, Remessa para locais de outros foros.</pre>",
                "LastUpdateTime": 1690401363745,
                "Id": "4121460",
                "DisplayLabel": "Carga - PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Emissão de Mandados do sistema PG5.</p><pre>Alteração de Dados, Alteração de Sigilo, Analítico de Atos e Diligências, CEPs Vinculados com Zonas, Cancelamento (Mandado), Cancelamento de Cargas, Classificação ou Prazo, Consulta Avançada (PG), Consulta Básica, Consulta de Cargas, Consulta de Mandados em Carga, Contramandados Excepcionais (SAJ), Cumprimento, Demonstrativo das Distribuições, Demonstrativo de Pesos Globais, Demonstrativo de Pesos Locais, Desentranhamento, Diagnóstico, Distribuição (Mandados), Distribuídos por Oficial, Emissão de Certidões, Emissão de Documentos (Mandados), Etiquetas de Numeração, Forma de Pagamento, Mandado Excepcional (Outros Locais), Mandado Excepcional (SAJ), Mandados Vencidos, Oficiais de Plantão, Pagamentos dos Atos e Diligências do Oficial, Recebimento da Central de Mandados, Recebimento do Agente, Recebimento do Cartório, Recebimento para a Central de Mandados, Redistribuição, Reemissão do Comprovante de Remessa (Mandados), Reemissão do Comprovante de Remessa por Data, Relatórios de emissão mandados, Remessa para o Agente, Remessa para o Cartório, Rol de Mandados de Prisão, Situação, Transferência.</pre>",
                "LastUpdateTime": 1690401426925,
                "Id": "4121485",
                "DisplayLabel": "Emissão de Mandados"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Andamento processual do sistema SG5.</p><pre>Alteração da Destinação Final (SG), Apensamento ou Desapensamento (SG), Arquivamento de Petição Intermediária, Associação de Processos, Atribuição de Cadastrador Responsável de Processo, Cadastro de Temas (Andamento processual), Cancelamento Arquivamento de Petição, Cancelamento da Juntada de Petição (SG), Cancelamento de Envio de Processo ao 1º Grau, Consulta Senha do Processo, Correção da Vinculação com o Processo Principal, Definição de Pacote, Devolução de Processo ao 1º Grau, Evolução de classe, Fluxo de Trabalho (Andamento processual SG), Grupos de Processos, Juntada de Petição Intermediária (SG), Localização Física Unitária (SG), Localização Física em Lote (SG), Movimentação Unitária (SG), Movimentação em Lote (SG), Pendências e Prazos (SG), Pendências e Prazos em Lote, Peso do Processo Físico, Porte de remessa para STF ou STJ, Resposta do Termo de Análise, Vinculação de Processos com Temas (SG), Vinculação de Usuário ao Processo de Sigilo Absoluto.</pre>",
                "LastUpdateTime": 1690401362006,
                "Id": "4121611",
                "DisplayLabel": "Andamento processual - SG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo&nbsp;Adolescentes Apreendidos ou Internados do módulo Adolescente em conflito com a Lei - Histórico do adolescente do sistema PG5</p><pre>Adolescentes Apreendidos ou Internados, Cadastro de Processo em Execução, Guia de Execução (Histórico do adolescente), Histórico de Adolescentes em Conflito com a Lei, Relatório de histórico do adolescente.\n</pre>",
                "LastUpdateTime": 1690401363677,
                "Id": "4121620",
                "DisplayLabel": "Adolescente em conflito com a Lei - Histórico do adolescente"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Certidões do sistema PG5.</p><pre>Ajuda Certidões PG, Alteração da Situação do Pedido (Certidões PG), Apoio (Certidões PG), Arrecadação (Certidões PG), Assinaturas (Certidões PG), Cadastro de Pedidos (Certidões PG), Consulta de Auditoria (Certidões PG), Consulta de certidões PG, Entrega (Certidões PG), Estatística das Filas (Certidões PG), Fila (Certidões PG), Limite da Distribuição (Certidões PG), Modelos de Certidão (Certidões PG), PSS (processador de certidões), Pedidos (PG), Pedidos Expirados (PG), Pedidos Militância (PG), Processo Antigos do Primeiro Grau, Processos (PG), Relatório de certidões PG, Status Aguardando Análise, Status Aguardando Entrega, Status Aguardando Impressão, Status Aguardando Pagamento, Status Aguardando Pagamento da Guia, Status Aguardando Pesquisa Manual, Status Aguardando Processamento, Status Análise Suspensa, Status Processamento Suspenso, Status em Análise, Status em Pesquisa Manual, Status em Processamento, Verificação da Vinculação de Classes (Certidões PG), Verificação do Processamento do Pedido (PG), Única (PG).</pre>",
                "LastUpdateTime": 1690401363182,
                "Id": "4121649",
                "DisplayLabel": "Certidões - PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Emissão de Expediente do sistema PG5.</p><pre>Assinaturas (Emissão de expediente), Cadastro de Autotextos (PG), Cadastro de Modelos de Documento (PG), Configurações do Usuário (PG), Confirmação de Movimentação (PG), Documentos Recentes (PG), Editor de Documentos (PG), Emissão de Documentos (Expediente PG), Gerenciador de Arquivos (PG), Relatório de emissão expediente.\n</pre>",
                "LastUpdateTime": 1690401363478,
                "Id": "4121676",
                "DisplayLabel": "Emissão de Expediente - PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Controladoria de mandados do sistema PG5.</p><pre>Analítico de Atos Judiciais, Analítico de Avaliação, Analítico de Desempenho, Analítico de Quilometragem, Autorização de Pagamentos, Controladoria, Custas (Mandados), Devolução de Mandados, Fechamento de Períodos, Guias Contabilizadas no Fechamento, Guias Vinculadas após Fechamento do Mandado, Guias com Valor Confirmado, Guias de Recolhimento de Diligências, Indenização de Transportes, Notas dos Agentes, Pagamentos de Indenização de Transportes, Períodos de Fechamentos, Recolhimento Pagos ao Oficial de Justiça, Relatórios da Controladoria, Retificação de Valor Vinculado ao Mandado, Validação de Mandados, Vinculação de Guias a Mandados.</pre>",
                "LastUpdateTime": 1690401427357,
                "Id": "4122011",
                "DisplayLabel": "Controladoria de mandados"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo&nbsp;Emissão de Ofício com AR do sistema PG5</p><pre>ARs digitais, ARs não emitidas por CEPs sem cobertura, Alteração de ARs (PG), Cancelamento de ARs (PG), Cancelamento de Juntade de ARs, Consulta de ARs com Juntada Pendente (PG), Consulta de ARs não Devolvidos pela ECT (PG), Consulta de ARs por Grupos de Estado (PG), Consulta de Avisos de Recebimento (PG), Consulta de Cargas por AR (PG), Emissão de Documentos (Ofício com AR), Juntada de ARs (Emissão com ofício), Recebimento de Ars (PG), Registro de Devolução da ECT (PG), Relatórios de emissão ofício, Remessa de ARs (Emissão com ofício).\n</pre>",
                "LastUpdateTime": 1690401427785,
                "Id": "4122038",
                "DisplayLabel": "Emissão de Ofício com AR"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Fluxo do sistema PG5.</p><pre>Fluxo de trabalho, Processamento paralelo.</pre>",
                "LastUpdateTime": 1690401448720,
                "Id": "4122079",
                "DisplayLabel": "Fluxo"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Integração PG e SG do sistema PG5.</p><pre>Declínio de Competência (Integração PG), Devolução de Carta de Ordem (Integração PG), Devolução do Pedido de Diligência (Integração PG), Devolução do Pedido de Informações (Integração PG), Envio de Processos ao 2º Grau (Integração PG), Envio de Recurso Eletrônico (Integração PG), MNI, Webservice de intimação ou citação eletrônica, Webservice de peticionamento inicial ou intermediário.</pre>",
                "LastUpdateTime": 1690401482782,
                "Id": "4122080",
                "DisplayLabel": "Integração PG e SG"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Fluxo de Trabalho PG5 do sistema PG5.</p><pre>Limpeza de Petições, Portal Empresas, Portal IMESC.</pre>",
                "LastUpdateTime": 1690401428200,
                "Id": "4122413",
                "DisplayLabel": "Fluxo de Trabalho PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Gestão de Armas do sistema PG5.</p><pre>Recebimento de armas, Solicitação de guarda, Solicitação de retirada.</pre>",
                "LastUpdateTime": 1690401465831,
                "Id": "4122414",
                "DisplayLabel": "Gestão de Armas - PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Gravação de Audiências do sistema PG5.</p><pre>Editor de texto, Vinculação de Usuários a Gravação de Sigilo.</pre>",
                "LastUpdateTime": 1690401482696,
                "Id": "4122415",
                "DisplayLabel": "Gravação de Audiências"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Pauta de audiências do sistema PG5.</p><pre>Corrido, Indisponibilidade de Salas, Pauta de Audiência, Pauta de Audiências da Sala, Pauta de Audiências em Bloco, Relatório de pauta de audiências, Tabelado.</pre>",
                "LastUpdateTime": 1690401465562,
                "Id": "4122420",
                "DisplayLabel": "Pauta de audiências - PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Precatórios e RPVs do sistema PG5.</p><pre>Apuração da Receita Corrente Líquida, Atualização Monetária e Cálculo de Juros do Processo, Atualização de Dívidas para a Gestão, Base de Cálculo para Alíquota Mensal, Cadastro de Acordos, Cadastro de Apuração da Alíquota Mensal, Cadastro de Apuração da Receita Corrente Líquida, Cadastro de Contas de Depósitos, Cadastro de Dívidas da Entidade Devedora, Cadastro de Histórico de Valores, Cadastro de Parcelamentos, Cadastro de Perguntas para a Entidade Devedora, Cadastro de Regimes da Entidade Devedora, Cadastro de Respostas para a Entidade Devedora, Cadastro de Sucessões, Cadastro de Tipos de Movimentação Financeiras, Cadastro de Tribunais, Cancelamento do número de ordem, Conferência de Contas de Credores, Configuração de Pagamentos, Consulta Anual dos Precatórios por Situação, Conta de Liquidação Orçamentária, Controle Financeiro de Gestão, Controle Financeiro de Pagamento, Controle de Publicação dos Depósitos Realizados, Cálculo de Dívida para o Percentual de Rateio, Cálculo dos Percentuais de Rateio e da Dívida Efetiva, Dados da Parte na Classificação, Demonstrativo de Atualização, Demonstrativo de Cálculo, Entidades Devedoras, Geração do número de ordem, Gestão, Gestão de Pagamentos, Histórico de Pagamentos, Lista de Requisitórios com Pagamentos Pendentes, Mapa Orçamentário, Mapa Orçamentário Consolidado, Ordem, Pagamento, Prévia de Pagamentos, Quadro de Pagamentos Disponibilizados, Registro de Pagamentos Ocorridos, Relatório Demonstrativo de Repasses, Relatório Estatístico de Requisitórios, Relatório com o Total de Depósitos Efetuados pelas Entidades, Relatório de Alíquotas e Valores (Projeção de Quitação), Relatório de Cálculo da Dívida Efetiva, Relatório de Dívidas em Outros Tribunais, Relatório de Entidades Públicas que Passaram para o Regime Ordinário, Relatório de Pagamentos Disponibilizados, Relatório de Perguntas e Respostas das Entidades Devedoras, Relatório de Precatórios Pendentes por Municípios CNJ, Relatório de Publicação de Depósitos, Relatório de Suficiência das Entidades Devedoras, Relatório de Suficiência no Pagamento de Parcelas, Relatório de Suficiência por Alíquota, Relatórios de precatórios, Relação de Números de Ordem para Publicação, Relação de Processos de Requisitórios, Repasse de Valores aos Tribunais, Requisitórios, Resumo do Cadastro, Resumo do Pagamento, Vinculação entre Entidades Devedoras e Tribunais.</pre>",
                "LastUpdateTime": 1690401482593,
                "Id": "4122422",
                "DisplayLabel": "Precatórios e RPVs"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Protocolo do sistema PG5.</p><pre>Ajuda protocolo PG, Andamento, Auditoria (Protocolo), Consulta de protocolo, Excepcional de Petições Iniciais, Excepcional de Petições Intermediárias e Documentos, Movimentação (Protocolo), Petições Iniciais, Petições Iniciais Aguardando Cadastro (Protocolo), Petições Intermediárias Aguardando Cadastro (Protocolo), Petições Intermediárias e Documentos, Petições Intermediárias e Incidentes Processuais (Protocolo), Petições Intermediárias e Incidentes Processuais Excepcionais, Relatório de protocolo PG, Remessa (Protocolo), Varas (Protocolo).</pre>",
                "LastUpdateTime": 1690401503278,
                "Id": "4122430",
                "DisplayLabel": "Protocolo - PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Estatística do sistema PG5.</p><pre>Afastamento dos Magistrados, Agrupador de Movimentações, Agrupamento de Assunto (PG), Agrupamento de Classe (PG), Agrupamento de Classe à Movimentação (PG), Agrupamento de Movimentação (PG), Agrupamento de Situação (PG), Agrupamento de Tipo de Audiência, Apoio (Estatística), Atualização dos Dados do SAJ-EST, Audiência, Cadastro Magistrado do CNJ, Cadastro Município do CNJ, Cadastro Serventia do CNJ, Cadastro de Mapas Estatísticos (PG), Carga (Estatística), Cartas e Juntadas com Prazo Vencido, Configuração de Mapas Estatísticos (PG), Consulta de Juiz Titular, Consulta de Processos Aptos para Eliminação, Criminal, Currículo do Magistrado, Destinação Final, Disponibilizar Meta 7 na Internet, Documentos Emitidos por Usuário (PG), ENASP - Metas 3 e 4, Equivalência, Equivalência à Vara, Gerencial da Vara, Gestão Documental, Indicadores Estratégicos, Informações para o CNJ, Item de Agrupamento (PG), Juiz Titular, Justiça Aberta - Gerar XML, Justiça Aberta - Gerar XML Portaria 125, Mandados, Mapas Estatísticos, Meta 7 - Publicação da Produtividade da Serventia e Magistrado, Metas Antigas CNJ, Metas CNJ, Movimentações por Usuário (PG), Movimento Forense, Municípios Atendidos por Serventia, Prazos de Movimentações Vencidas, Processos Conclusos, Processos Mais Antigos, Processos Sem Movimentação, Processos Sigilosos, Processômetro, Produtividade Média do Magistrado, Produção do Magistrado, Relatório de Mapas Estatísticos, Relatório de estatística PG, Resolução 76 - Anexo II - Gerar XML, Resolução 76 - Primeira Edição, Resolução 76 - Terceira Edição, Réu Preso, Selo da Justiça - Gerar (Enviar) XML Portaria 56, Situacional, Tempo Médio de Sentença, Tipo de Agrupamento (PG), Totalizador de Distribuições, Totalizador de Eventos, Totalizador de Movimentações.</pre>",
                "LastUpdateTime": 1690401448761,
                "Id": "4122598",
                "DisplayLabel": "Estatística"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Integração com o BNMP 2.0 do sistema PG5.</p><pre>Alvarás de Soltura Excepcionais, Arquivamento de Guias, Consulta de Acervo, Consulta de Histórico de RJI no Processo, Consulta de Pessoas, Consulta de Peças, Consulta de Prisões sem Mandado, Ordens de Desinternação Excepcionais, Ordens de Liberação Excepcionais, Registro de Guias de Acervo, Registro de Mandados Cumpridos, Relatório de Regularização de Acervo, Resolução de Contingência de Alvarás, Resolução de Contingência de Mandados, Teste de Comunicação.</pre>",
                "LastUpdateTime": 1690401483025,
                "Id": "4122618",
                "DisplayLabel": "Integração com o BNMP 2.0"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Pasta Digital do sistema PG5.</p><pre>Autos (Pasta digital), Consulta de pasta PG, Liberação de documentos.</pre>",
                "LastUpdateTime": 1690401466378,
                "Id": "4122623",
                "DisplayLabel": "Pasta Digital - PG5"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Publicação (Intimação de advogados)&nbsp;do sistema PG5.</p><pre>Certidão de Emissão, Certidão de Publicação, Configuração de publicação, Consulta de Relações, Devolução de Autos, Eliminação de Autos, Intimação de Advogados, Intimação eletrônica, Numeração de Ordem, Processos Distribuídos.</pre>",
                "LastUpdateTime": 1690401504255,
                "Id": "4122666",
                "DisplayLabel": "Publicação (Intimação de advogados)"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ PG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ PG5</p><p><strong>SERVIÇO</strong>: PG5</p><p>Módulo Utilitários do sistema PG5.</p><pre>Ajuste de Pesos de Varas, Alteração Unitária da Localização Física, Alteração em Bloco da Localização Física, Aplicativos, Base de Conhecimento (PG), Biblioteca, Cadastro de utilitários PG, Catálogo de Endereços, Configuração da Estação, Configuração da Sala, Configuração da qualidade de som em audiências, Configuração das Seções, Consultas, Correção da Vara da Última Distribuição, Cópia de Arquivo de Execução Fiscal para o Servidor, Cópia de Arquivo de Importação de Petições Intermediárias, Cópia de Arquivo de Saída de Execução Fiscal, Cópia de Arquivo de Saída de Petições Intermediárias, Devolução de Processos entre Magistrados, Ferramentas, Habilitação de Advogados, Histórico de Localização Física, Horário de Atendimento ao Público, Importar Arquivo de Empresa Conveniada, OAB - Alteração da Situação do Advogado, Opção \"Zerar Pesos de Varas\", Pauta de Audiência (Utilitários), Transferência de Movimentação, Transferência de Processos entre Magistrados (PG), Transferência de Processos entre Promotores, Transferência de Processos entre Vagas, Transferência de Processos entre Varas, Unificação de Advogados.</pre>",
                "LastUpdateTime": 1690401503936,
                "Id": "4122671",
                "DisplayLabel": "Utilitários"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo ALX - Almoxarifado do sistema SAJ ADM (Administrativo).</p><pre>Almoxarifado, Consultas, Inventário, Movimentação de materiais, Relatórios.</pre>",
                "LastUpdateTime": 1690401427982,
                "Id": "4122684",
                "DisplayLabel": "ALX - Almoxarifado"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo CPA - MRP - Reuniões e Pautas&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Calendário de Reunião, Reuniões.</pre>",
                "LastUpdateTime": 1690401428312,
                "Id": "4125844",
                "DisplayLabel": "CPA - MRP - Reuniões e Pautas"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo FRT - Frotas&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Abastecimento / Lavação, Apoio - Condutor Operador, Documentação, Manutenção, Ocorrências, Relatórios, Utilização, Veículos.</pre>",
                "LastUpdateTime": 1690401482910,
                "Id": "4125874",
                "DisplayLabel": "FRT - Frotas"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo MLJ - Mandado de Levantamento Judicial&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Geração de Guias, MLJ - Mandado de Levantamento Judicial.</pre>",
                "LastUpdateTime": 1690401483054,
                "Id": "4125881",
                "DisplayLabel": "MLJ - Mandado de Levantamento Judicial"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo Portal da Magistratura do sistema SAJ ADM (Administrativo).</p><pre>Benefícios, Requerimentos.</pre>",
                "LastUpdateTime": 1690401483218,
                "Id": "4125882",
                "DisplayLabel": "PORTAL DA MAGISTRATURA"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo SCL - Compras e Licitações&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Cadastro Simplificado de Leilão, Consultas e Relatórios, Fornecedores, Licitações, Pesquisa de preço.</pre>",
                "LastUpdateTime": 1690401503152,
                "Id": "4125901",
                "DisplayLabel": "SCL - Compras e Licitações"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo AUDESP&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Exportação dos dados, Painel Gerencial, Relatórios.</pre>",
                "LastUpdateTime": 1690401427442,
                "Id": "4126048",
                "DisplayLabel": "AUDESP"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo CPA - Gestão de Processos Administrativos&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Assinatura de documentos, Autuação de protocolo, Cadastro de processo digital, Cadastro de protocolo digital, Comunique-se, Consulta de processo, Consulta textual, Lotes, Portal Solicitações, Processo, Protocolo, Relatórios, Tramitação.</pre>",
                "LastUpdateTime": 1690401427769,
                "Id": "4126055",
                "DisplayLabel": "CPA - Gestão de Processos Administrativos"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo GECON - Gestão do Conhecimento Judiciário&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Cadastros, Consultas, Importação de Dados, Relatórios.</pre>",
                "LastUpdateTime": 1690401481985,
                "Id": "4126931",
                "DisplayLabel": "GECON - Gestão do Conhecimento Judiciário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo&nbsp;PDB - Promoções - &nbsp;Designações e Benefícios&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Diárias e Benefícios, Promoção.</pre>",
                "LastUpdateTime": 1690401483077,
                "Id": "4126936",
                "DisplayLabel": "PDB - Promoções - Designações e Benefícios"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo PEX - Corregedoria da Justiça do sistema SAJ ADM (Administrativo).</p><pre>Comunicados, Corregedores Permanentes, Funcionários, Imóveis Rurais, Outras Publicações, Unidades Extrajudiciais.</pre>",
                "LastUpdateTime": 1690401482300,
                "Id": "4126937",
                "DisplayLabel": "PEX - Corregedoria da Justiça"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo Portal Extrajudicial&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Declaração Mensal, Declaração Semanal, Guias Antigas, Quadro Funcional, Selos.</pre>",
                "LastUpdateTime": 1690401482574,
                "Id": "4126944",
                "DisplayLabel": "Portal Extrajudicial"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo SIP - Patrimônio&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Bens Imóveis, Bens Móveis, Consultas e Relatórios, Contabilidade, Documentos, Inventário, Movimentação.</pre>",
                "LastUpdateTime": 1690401503135,
                "Id": "4126957",
                "DisplayLabel": "SIP - Patrimônio"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo SMG - Mandados Gratuitos&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Funcionários, Oficiais de Justiça, Relatório.</pre>",
                "LastUpdateTime": 1690401504526,
                "Id": "4126960",
                "DisplayLabel": "SMG - Mandados Gratuitos"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo MEM - Malas e Malotes do sistema SAJ ADM (Administrativo).</p><pre>Ajuda, Correios, Documentos, Malas/Malotes, Prestação de contas, Relatórios, Triagem.</pre>",
                "LastUpdateTime": 1690401483000,
                "Id": "4127115",
                "DisplayLabel": "MEM - Malas e Malotes"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo PEX PTL - Portal Extra Judicial&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Portal Extra Judicial.</pre>",
                "LastUpdateTime": 1690401483453,
                "Id": "4127118",
                "DisplayLabel": "PEX PTL - Portal Extra Judicial"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo&nbsp;POS - Proposta Orçamentária Setorial&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Coleta, Consolidação, Exportação, Solicitações.</pre>",
                "LastUpdateTime": 1690401484081,
                "Id": "4127119",
                "DisplayLabel": "POS - Proposta Orçamentária Setorial"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo REC - Receitas&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Receitas, Relatórios.</pre>",
                "LastUpdateTime": 1690401504689,
                "Id": "4127120",
                "DisplayLabel": "REC - Receitas"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo SGF - Financeiro e Orçamentário&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Alterações Contratuais, Consultas e Relatórios, Contrato, Despesas, Integração Siafem, Orçamento, Painel Gerencial.</pre>",
                "LastUpdateTime": 1690401504769,
                "Id": "4127139",
                "DisplayLabel": "SGF - Financeiro e Orçamentário"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ ADM",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ ADM</p><p><strong>SERVIÇO</strong>:&nbsp;SAJ ADM (Administrativo)</p><p>Módulo&nbsp;SPD - Pedidos&nbsp;do sistema SAJ ADM (Administrativo).</p><pre>Catálogo de Materiais, Consultas Gerenciais, Consultas e Relatórios, Pedidos.</pre>",
                "LastUpdateTime": 1690401503522,
                "Id": "4127506",
                "DisplayLabel": "SPD - Pedidos"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SAJ ADM (Administrativo)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "SAJ SG5",
                "Description": "<p><strong>CATEGORIA</strong>: SAJ SG5</p><p><strong>SERVIÇO</strong>: SG5</p><p>Módulo Jurisprudência do sistema CONFIGURAÇÕES.</p><pre>Sigilo Externo, Sigilo absoluto.</pre>",
                "LastUpdateTime": 1690401483909,
                "Id": "4127542",
                "DisplayLabel": "Jurisprudência"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "SG5"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Confecção de rede de acesso temporário ao ambiente do TJ.</p><p></p><pre>Cabo de rede (metros), RJ 45 (unidade), Keystone (unidade), Patch Cord 1.5 m (unidade), Patch Cord 2.5 m (unidade).</pre>",
                "LastUpdateTime": 1690401427063,
                "Id": "4127936",
                "DisplayLabel": "DESKTOP - Confecção de rede temporária"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DESKTOP"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Para registros de problemas, erros e falhas referentes a utilização de impressora.</p>",
                "LastUpdateTime": 1690401483732,
                "Id": "4127970",
                "DisplayLabel": "IMPRESSORAS - Estou com problemas com uma Impressora"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "IMPRESSORAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<pre>Para registros de problemas, erros e falhas referentes a utilização de projetor.</pre>",
                "LastUpdateTime": 1690401483345,
                "Id": "4128001",
                "DisplayLabel": "PROJETOR - Estou com problemas em um projetor"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PROJETOR"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Fornecimento de equipamento desktop para colaborador , Fornecimento de equipamento de rede, Fornecimento de equipamento de impressoras outsourcing, Fornecimento de licenças de Softwares Deficiente Visual, Mudanças de desktops para outros departamentos ou localidades do TJSP.</p><p></p><p></p><pre>CPU, Filtro de linha, Headset, Impressora Autenticadora, Impressora Laser Policromatica, Leitor de Código de Barras, Microfone omnidirecional, Monitor, Monitor (Deficiente Visual), Monitor 21' (Magistrado), Notebook, Relógio de Ponto Biometrico, Suporte Articulado de Mesa para Monitor (Deficiente Visual), WebCam, Workstation, Desktop para colaborador, Equipamento de rede, Equipamento de impressoras outsourcing, Licenças de Softwares Deficiente Visual, Mudanças de desktops para outros departamentos ou localidades do TJSP.</pre>",
                "LastUpdateTime": 1690401427774,
                "Id": "4128054",
                "DisplayLabel": "DESKTOP - Fornecimento de equipamentos"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DESKTOP"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Para registros de problemas, erros e falhas referentes a utilização de desktop.</p><p>Para registros de problemas, erros e falhas referentes a utilização de monitor.</p><p>Para registros de problemas, erros e falhas referentes a utilização de notebook.</p><p></p><pre>Problemas, erros e falhas referentes a utilização de desktop, Problemas, erros e falhas referentes a utilização de monitor, Problemas, erros e falhas referentes a utilização de notebook.</pre>",
                "LastUpdateTime": 1690401427715,
                "Id": "4128059",
                "DisplayLabel": "DESKTOP/NOTEBOOK/MONITOR - Estou com Problemas com Desktop, Notebook ou Monitor"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "DESKTOP"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<pre>Troca de tonners para impressoras, Troca de tonners para impressoras, Configuração de impressoras, Troca de unidade de imagem, Compartilhamento de impressora.\n</pre>",
                "LastUpdateTime": 1690401483113,
                "Id": "4128062",
                "DisplayLabel": "IMPRESSORAS - Solicitação de Serviços"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "IMPRESSORAS"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p></p><pre>Para registros de configuração de periféricos.</pre>",
                "LastUpdateTime": 1690401483072,
                "Id": "4128441",
                "DisplayLabel": "PERIFÉRICOS (HEADSET, MOUSE, TECLADO, WEBCAM) - Solicitação e Configuração de um periférico"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PERIFÉRICOS (HEADSET, MOUSE, TECLADO, WEBCAM)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Para registros de de manutenções , problemas, erros e falhas referentes a utilização de periféricos.</p><p></p><pre>Manutenção, Problema, Erro , Falha.</pre>",
                "LastUpdateTime": 1690401484042,
                "Id": "4128442",
                "DisplayLabel": "PERIFÉRICOS (HEADSET, MOUSE, TECLADO, WEBCAM) - Estou com problemas com um periférico"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PERIFÉRICOS (HEADSET, MOUSE, TECLADO, WEBCAM)"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p></p><pre>Manutenção preventiva de projetores, Instalação de projetores, Solicitação de cabos para projetores, Troca de locais de projetores, Troca de lâmpada.</pre>",
                "LastUpdateTime": 1690401504303,
                "Id": "4128447",
                "DisplayLabel": "PROJETOR - Solicitação de Instalação, Manutenção e Configuração de um projetor"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PROJETOR"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Troca de fitas / rolo térmico , Dúvidas referentes a utilização de protocolador.</p><p></p><pre>Dúvidas, Troca de Fita / Rolo Térmicos.</pre>",
                "LastUpdateTime": 1690401503765,
                "Id": "4128449",
                "DisplayLabel": "PROTOCOLADORA - Solicitação de Serviços"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PROTOCOLADORA"
                }
            }
        },
        {
            "entity_type": "Offering",
            "properties": {
                "TipoAcessoOferta_c": "Interno_c",
                "CatalogCategory_c": "DESKTOPS, LAPTOPS, IMPRESSORAS, PERIFÉRICO",
                "Description": "<p>Para registros de problemas, erros e falhas referentes a utilização de protocoladora.</p><p></p><pre>Problemas, Erros e Falhas.</pre>",
                "LastUpdateTime": 1690401504173,
                "Id": "4128450",
                "DisplayLabel": "PROTOCOLADORA - Estou com problemas com uma Protocoladora"
            },
            "related_properties": {
                "Service": {
                    "DisplayLabel": "PROTOCOLADORA"
                }
            }
        }
    ],
        "meta": {
        "completion_status": "OK",
        "total_count": 437,
        "errorDetailsList": [],
        "errorDetailsMetaList": [],
        "query_time": 1690488648910851
    }
    }
}

response = requests.post(
        url="http://127.0.0.1:8000/classificador",
        # url="https://cont-chatgpt-tjsp.purpleriver-6e4b402a.eastus2.azurecontainerapps.io/classificador",
        # url="https://cont-itsm-chatgpt-dev.jollydesert-65bdaf5e.eastus2.azurecontainerapps.io",
        json=body,
        headers={"API_KEY": "TJ!)#!@M#POPS"}
)


print(response.text)