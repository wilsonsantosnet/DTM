import logging

from azure.cosmos import CosmosClient, PartitionKey
from azure.cosmos.exceptions import CosmosResourceNotFoundError

import os

from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


def _format_chat_history(chat_history):
    messages_formated = []
    chat_history_only_questions = []

    for message in chat_history:

        messages_formated.append(f'HUMAN_INPUT: {message["HUMAN_INPUT"]}')
        messages_formated.append(f'AI: {message["AI"]}')
        chat_history_only_questions.append(message['HUMAN_INPUT'])

    return '\n'.join(messages_formated), ' '.join(chat_history_only_questions)


URL = os.environ['COSMOS_URL']
KEY = os.environ['COSMOS_KEY']

# def get_chat_history(pre_session, session):

DATABASE_NAME = "chat-gpt-history"
pre_session = "tjsp"
session = "1"

client = CosmosClient(URL, credential=KEY)

client.create_database_if_not_exists(DATABASE_NAME)

database = client.get_database_client(DATABASE_NAME)

database.create_container_if_not_exists(id=pre_session, partition_key=PartitionKey(path="/id"))

container = database.get_container_client(pre_session)

try:
    item = container.read_item(session, partition_key=session)
except CosmosResourceNotFoundError:
    logger.info(f"Chat History Vazio para session '{session}'")
    item = {}

chat_history = item['chat_history']

chat_history_formated = _format_chat_history(chat_history)
