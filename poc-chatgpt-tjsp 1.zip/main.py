import logging
import uuid

from dotenv import load_dotenv
from fastapi import FastAPI, Body, Request, Response
from pydantic import BaseModel

from gpt_api import GPTTjsp, GPTTjspClassificador, GPTTjspDescricao
from gpt_api.config import setup_logging

# Configura logging
setup_logging()

logger = logging.getLogger(__name__)

app = FastAPI()

# take environment variables from .env.
load_dotenv()

API_KEY = "TJ!)#!@M#POPS"


class RequestBody(BaseModel):
    message: str
    user: str
    session: str
    model: str


@app.post("/descricao")
async def descricao(
        request: Request,
        request_body: dict
):

    header_api_key = request.headers.get('API_KEY')
    if header_api_key != API_KEY:
        return Response(
            content=f"A API_KEY provisionada no headers está incorreta ({header_api_key}). ",
            status_code=401
        )

    chat_history = request_body['chat_history']

    gpt = GPTTjspDescricao()

    descricao = gpt.execute(chat_history=chat_history)

    return descricao


@app.post("/classificador")
async def classificador(
        request: Request,
        request_body: dict
):

    header_api_key = request.headers.get('API_KEY')
    if header_api_key != API_KEY:
        return Response(
            content=f"A API_KEY provisionada no headers está incorreta ({header_api_key}). ",
            status_code=401
        )

    ofertas = request_body['ofertas']
    descricao = request_body['descricao']

    gpt = GPTTjspClassificador()

    id_categoria = gpt.execute(descricao=descricao, ofertas=ofertas)

    return id_categoria


@app.post("/")
async def chat(
    request: Request,
    request_body: RequestBody = Body(...)
):

    exec_id = str(uuid.uuid4())

    message = request_body.message
    user = request_body.user
    session = request_body.session
    model = request_body.model

    header_api_key = request.headers.get('API_KEY')
    if header_api_key != API_KEY:
        return Response(
            content=f"A API_KEY provisionada no headers está incorreta ({header_api_key}). ",
            status_code=401
        )

    # Chamada à API real do OpenAI usando os parâmetros do request_body
    gpt = GPTTjsp()  # Por enquanto invocando somente o gpt-tjsp

    logger.info(
        f"exec_id: '{exec_id}' / "
        f"user: '{user}'  / "
        f"Session: '{session}' / "
        f"model: '{model}' /  "
        f"message: '{message}'"
    )

    user_session = user + session

    # Execução do chatgpt
    response, chat_history = gpt.execute(session=user_session, message=message)

    api_response = {
        "id": exec_id,
        "model": model,
        "message": message,
        "response": response,
        "user_session": user_session,
        "user": user,
        "session": session,
        "chat_history": chat_history
        }

    logger.info(f"exec_id: '{exec_id}' / response: {response}")

    return api_response

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
