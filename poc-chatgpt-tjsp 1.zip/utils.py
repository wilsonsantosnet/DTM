from langchain import LLMChain
from langchain.prompts import load_prompt

def execute_prompt(llm, prompt_dir, prompt_args: dict, verbose=True):
    prompt = load_prompt(prompt_dir)
    llm_chain = LLMChain(prompt=prompt, llm=llm, verbose=verbose)
    prompt_result = llm_chain.predict(**prompt_args)
    return prompt_result
