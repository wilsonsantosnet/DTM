import json
import uuid

# from execute_gpt_descricao import response_resume
from gpt_api import GPTTjspClassificador
from dotenv import load_dotenv

load_dotenv()

# Caminho para o arquivo JSON
file_path = 'tests/json_ofertas.json'

# Carregar o conteúdo do arquivo JSON em um objeto Python
with open(file_path, 'r', encoding='utf-8') as file:
    data = json.load(file)

gpt = GPTTjspClassificador()

response_resume = """
"""

response = gpt.execute(descricao=response_resume, ofertas=data)
print(response)

