### Lembre-se de para testar local, instalar o azure-search-documents

pip install -r requirements.txt

pip install --index-url=https://pkgs.dev.azure.com/azure-sdk/public/_packaging/azure-sdk-for-python/pypi/simple/ azure-search-documents==11.4.0a20230509004

 

### Build da imagem pro ACR

az login

az account set --subscription "bb7eb198-dcfe-47a4-aef9-be5909f07478"

az acr build --registry "acritsmchatgptdev" --image gpt-api .

 

### diretório data/pdfs

guarda os documentos pdfs utilizados.

 

### dataprep.py

faz toda preparação dos PDFs vindo do diretório data/pdfs

retirando rodapés, números das paginas, fazendo parse do sumário de cada pdf, quebrando em chunks e guardando em um json temporário.

 

### ingest.py

faz a ingestão dos dados na VectorStore (azure cognitive search).

 

### diretório gpt_api

 

gpt_api/gpt_tjsp.py

 

A Classe GPTTjsp tem o objetivo de realizar conversas, usando o contexto e os documentos indexados, utiliza o Azure como base para armazenamento, busca e processamento das informações. Durante a execução, recupera informações relevantes utilizando a VectorStore, recupera e armazena o histórico de conversas no Cosmos, e trabalha a contextualização do input gerando respostas para as perguntas.

 

----------------------------------------------------

 

gpt_api/gpt_tjsp_descricao.py

 

A Classe GPTTjspDescricao utiliza o modelo GPT para gerar descrições textuais. Usa o Azure como base para conexões e armazenamento de informações e, ao ser executada, ela processa o histórico de conversas fornecido para criar uma descrição.

 

----------------------------------------------------

 

gpt_api/gpt_tjsp_classificador.py

 

A classe GPTTjspClassificador utiliza o modelo GPT para classificar com base em sua descrição e nas ofertas. Configura a conexão com a API usando o Azure e carrega os prompts de classificação. Ao executar a classificação, a função execute processa a descrição e as ofertas fornecidas e retorna as principais categorias relacionadas.

 

----------------------------------------------------

 

### diretório prompts

guarda todos os prompts utilizados pelas Classes

### main.py

Onde fica o código principal orquestrando as rotas das APIs,

O código cria uma aplicação FastAPI com 3 endpoints: "/descricao", "/classificador" e "/". A aplicação usa os módulos GPTTjsp, GPTTjspClassificador e GPTTjspDescricao que implementam funcionalidades com o modelo GPT-3 da OpenAI.

 

O endpoint "/" realiza as conversas utilizando o modelo GPT.

O endpoint "/descricao" gera uma descrição textual com base no histórico de conversa fornecido.

O endpoint "/classificador" classifica com base na descrição e no conjunto de ofertas.

 

### teste_execute_gpt.py

executa o código localmente instanciando a Classe GPTTjsp, podendo realizar testes de perguntas para obter respostas do modelo.

 

### teste_execute_gpt_descricao.py

executa o código localmente instanciando a Classe GPTTjspDescricao, podendo realizar testes, passando descrições para obter respostas do modelo.

 

 

### teste_execute_gpt_classificador.py

executa o código localmente instanciando a Classe GPTTjspClassificador, podendo realizar testes, passando descrições para ser gerada classificações pelo modelo.

 