import json
import uuid

from gpt_api import GPTTjspDescricao
from dotenv import load_dotenv

load_dotenv()

gpt = GPTTjspDescricao()

response_resume = gpt.execute(chat_history='Bruno da Silva: Como faço para inserir penas de multa? \n ChatGPT: Para inserir penas de multa, você deve clicar no botão com o símbolo de adição na tela de Cadastro das Penas de Multa. Em seguida, preencha os campos "Dias-multa" e "Valor do dia-multa em SM" e clique em "Salvar". O sistema apresentará a seção "Pena de Multa" preenchida. Lembre-se de preencher também o campo "Regime Prisional" com uma das opções apresentadas pelo sistema. O documento utilizado foi "BNMP - Saneamento - Preso Provisório - Emissão da Guia no CNJ - PARTE II - 16.02.2023.pdf", no tópico "Penas de Multa", subtópico "None".'
)

print(response_resume)