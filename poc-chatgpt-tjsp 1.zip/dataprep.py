from dotenv import load_dotenv
import os
import json

# Imports de lang chain - Framework para dev de aplicações de linguagem. Chama modelos via API.
from langchain.chat_models import AzureChatOpenAI
from langchain.document_loaders import PDFPlumberLoader

from utils import execute_prompt

# Carrega variaveis do .env
load_dotenv()

# Configuração do serviço do AzureOpenAI
llm = AzureChatOpenAI(deployment_name=os.getenv("DEPLOYMENT_NAME"), temperature=0.0)

# Carrega arquivos da Base de conhecimentos fornecidos pelo TJSP - Saneamento - Preso Provisório
docs_path = os.path.abspath("data/pdfs")

list_of_documents_path = [os.path.join(docs_path, file) for file in os.listdir(docs_path)]

list_of_documents = []

for doc_name in list_of_documents_path:
    print(f"Carregando doc '{doc_name}'")
    loader = PDFPlumberLoader(doc_name)
    document_pages = loader.load()
    list_of_documents.append(document_pages)

# Limpeza dos caminhos de origem dos documentos e rodapes dos documentos
list_of_parsed_documents = []

for documents in list_of_documents:
    document_name = documents[0].metadata['source'].split("\\")[-1]
    first_page = documents[0].page_content[2:]
    summary = documents[1].page_content[2:]
    cleaned_content = [x.page_content[2:] for x in documents[2:]]  # Retirando o numero da pagina
    content = '\n'.join(cleaned_content)

    # Identificando o rodapé
    partes = summary.rsplit('\n', 1)
    if not len(partes) > 1:
        raise ValueError("Nao encontrado \n no texto.")
    rodape = partes[-1].strip()

    list_of_parsed_documents.append(
        {
            "document_name": document_name,
            "first_page": first_page.replace(rodape, '').replace("\n", ' ').strip(),
            "summary": summary.replace(rodape, '').replace("SUMÁRIO", '').replace("\n", ' ').strip(),
            "content": content.replace(rodape, '').replace("\n", ' ').strip().replace("()", ""),
            'rodape': rodape
        })

# ### Definindo caminho dos prompts
prompts_dir = os.path.abspath("prompts")

for idx, doc in enumerate(list_of_parsed_documents):
    print(f"Executando parse do sumário do documento com idx '{idx}'")

    # Executa o prompt de tradução em todos os pedaços
    text_translated = execute_prompt(
        llm=llm,
        prompt_dir=f"{prompts_dir}/parse_summary.json",
        prompt_args={"summary": doc['summary']},
        verbose=True
    )

    # # Cria um json com o conteudo traduzido e o nome do documento de origem (metadata)
    doc['summary_parsed'] = json.loads(text_translated.replace("'", '"'))  # json.loads(text_translated)

# ### Utilizando o sumario para separação em chunks
for idx_docs, doc in enumerate(list_of_parsed_documents):

    sumario = doc['summary_parsed']
    content = doc['content']

    chunks_of_content = []

    for idx_summary, json_topico in enumerate(sumario):

        topico = json_topico['TOPICO']
        subtopicos = json_topico['SUBTOPICOS']

        if len(sumario) > idx_summary + 1:
            proximo_topico = sumario[idx_summary + 1]["TOPICO"]
        else:
            proximo_topico = None  # Estamos tratando o ultimo topico

        print(f"Tratando topico: {topico}")

        if len(subtopicos) == 0:  # Separar pelo topico

            indice_separador = content.find(topico)
            if indice_separador == -1:
                raise ValueError("Nao encontrado topico no content.")

            if proximo_topico:
                indice_separador_prox_topico = content.find(proximo_topico)
            else:
                indice_separador_prox_topico = None

            chunk = content[indice_separador:indice_separador_prox_topico]

            chunks_of_content.append(
                {
                    "topico": topico,
                    "subtopico": None,
                    "content": chunk,
                    'proximo_topico': proximo_topico,
                    'proximo_subtopico': None
                }
            )

        else:  # Separar pelo subtopico

            # Tratando primeiramente somente o Topico
            indice_separador = content.find(topico)
            if indice_separador == -1:
                raise ValueError("Nao encontrado topico no content.")
            indice_separador_ate_primeiro_subtopico = content.find(subtopicos[0])

            chunk = content[indice_separador:indice_separador_ate_primeiro_subtopico]

            chunks_of_content.append(
                {
                    "topico": topico,
                    "subtopico": None,
                    "content": chunk,
                    'proximo_topico': proximo_topico,
                    'proximo_subtopico': subtopicos[0]
                }
            )

            for idx_subtopics, subtopico in enumerate(subtopicos):

                if len(subtopicos) > idx_subtopics + 1:
                    proximo_subtopico = subtopicos[idx_subtopics + 1]
                else:
                    proximo_subtopico = None  # Estamos tratando o ultimo subtopico

                indice_separador = content.find(subtopico)

                if indice_separador == -1:
                    raise ValueError("Nao encontrado subtopico no content.")

                if proximo_subtopico:
                    indice_separador_prox_subtopico = content.find(proximo_subtopico)
                else:
                    if proximo_topico:
                        indice_separador_prox_subtopico = content.find(proximo_topico)
                    else:
                        indice_separador_prox_subtopico = None

                chunk = content[indice_separador:indice_separador_prox_subtopico]

                chunks_of_content.append(
                    {
                        "topico": topico,
                        "subtopico": subtopico,
                        "content": chunk,
                        'proximo_topico': proximo_topico,
                        'proximo_subtopico': proximo_subtopico
                    }
                )
    doc['chunks_of_contents'] = chunks_of_content

# Criando chunk final para ser traduzido
for doc in list_of_parsed_documents:
    for chunk in doc['chunks_of_contents']:
        chunk['final_chunk'] = f"NOME DO DOCUMENTO: {doc['document_name']} " \
                                      f"\n TOPICO: {chunk['topico']} " \
                                      f"\n SUBTOPICO: {chunk['subtopico']} " \
                                      f"\n CONTEUDO: {chunk['content']}"

# Gravando os documentos em um arquivo json temporario
with open(os.path.abspath('temp_data/documents.json'), 'w') as json_file:
    # Grava a lista de JSONs no arquivo
    json.dump(list_of_parsed_documents, json_file)
